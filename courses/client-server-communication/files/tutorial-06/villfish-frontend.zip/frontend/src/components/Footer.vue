<script>

export default {
	props: {
		copyrightYear: Number,
	},
}

</script>

<template>
	<footer>
		Copyright {{copyrightYear}}
	</footer>
</template>

<style scoped>

</style>
