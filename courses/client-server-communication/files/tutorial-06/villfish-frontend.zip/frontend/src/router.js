import { createRouter, createWebHistory } from 'vue-router'
import HomeView from './views/HomeView.vue'
import AdsView from './views/AdsView.vue'
import AccountsView from './views/AccountsView.vue'
import AdView from './views/AdView.vue'
import CreateAdView from './views/CreateAdView.vue'
import CreateAccountView from './views/CreateAccountView.vue'
import LoginView from './views/LoginView.vue'

const router = createRouter({
	history: createWebHistory(),
	routes: [
		{path: '/',      component: HomeView},
		{path: '/ads', component: AdsView},
		{path: '/ads/:id', component: AdView},
		{path: '/create-ad', component: CreateAdView},
		{path: '/accounts', component: AccountsView},
		{path: '/create-account', component: CreateAccountView},
		{path: '/login', component: LoginView},
	],
})

export default router
