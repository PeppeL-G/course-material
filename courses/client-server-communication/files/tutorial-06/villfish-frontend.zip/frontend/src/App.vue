<script>
import Footer from './components/Footer.vue'

export default {
	components: {
		Footer,
	},
	data(){
		return {
			// What we put inside this user object will be passed as
			// a "user" props to all Views in the "views" folder,
			// so all of them has access to it.
			user: {
				isLoggedIn: false,
				accessToken: "",
				username: "",
				accountId: 0,
			}
		}
	}
}

</script>

<template>
	
	<header>
		My app!
	</header>
	
	<nav>
		<RouterLink to="/">Start</RouterLink>
		<RouterLink to="/ads">Ads</RouterLink>
		<RouterLink to="/create-ad">Create Ad</RouterLink>
		<RouterLink to="/accounts">Accounts</RouterLink>
		<RouterLink to="/create-account">Create Account</RouterLink>
		<span v-if="user.isLoggedIn">
			You are logged in as {{user.username}} ({{user.accountId}})
		</span>
		<RouterLink to="/login">Login</RouterLink>
	</nav>
	
	<main>
		<RouterView :user="user"></RouterView>
	</main>
	
	<Footer :copyrightYear="2022"></Footer>
	
</template>

<style scoped>

nav{
	background-color: yellow;
	display: flex;
}

nav *{
	flex: 1;
	text-align: center;
}

</style>
