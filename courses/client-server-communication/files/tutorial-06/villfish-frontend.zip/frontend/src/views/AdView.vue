<script>
export default {
	data(){
		return {
			ad: {},
			errors: []
		}
	},
	mounted(){
		
		const id = this.$route.params.id
		
		fetch("http://localhost:8080/ads/"+id).then(response => {
			
			if(response.status == 200){
				
				response.json().then(ad => {
					this.ad = ad
				})
				
			}else if(response.status == 404){
				this.errors.push("No ad with the given id")
			}else if(response.status == 500){
				this.errors.push("Server couldn't carry out request")
			}
			
		})
		
	}
}
</script>

<template>
	<div class="page">
		<h1>Ad</h1>
		
		<div v-if="errors.length == 0">
			<div>Id: {{ad.id}}</div>
			<div>Type: {{ad.type}}</div>
			<div>Weight: {{ad.weight}}</div>
		</div>
		
		<div v-else>
			<p>Can't show the ad because:</p>
			<ul>
				<li v-for="error in errors">
					{{error}}
				</li>
			</ul>
		</div>
		
	</div>
</template>

<style scoped>

.page{
	background-color: lime;
}

</style>
