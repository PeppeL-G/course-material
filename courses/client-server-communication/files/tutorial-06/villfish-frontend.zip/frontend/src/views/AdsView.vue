<script>
	export default {
		data(){
			return {
				ads: [],
				errors: []
			}
		},
		mounted(){
			fetch("http://localhost:8080/ads").then(response => {
				
				if(response.status == 200){
					
					response.json().then(ads => {
						this.ads = ads
					})
					
				}else if(response.status == 500){
					this.errors.push("Server couldn't send back all ads")
				}
				
			})
		},
	}
</script>

<template>
	<div class="page">
		<h1>Ads</h1>
		
		<div v-if="errors.length == 0">
			<p>Here are all the ads!</p>
			<ul>
				<li v-for="ad in ads">
					<RouterLink :to="`/ads/${ad.id}`">
						{{ad.type}} {{ad.weight}}kg (accountId {{ad.accountId}})
					</RouterLink>
				</li>
			</ul>
		</div>
		
		<div v-else>
			<p>Can't show the ads because:</p>
			<ul>
				<li v-for="error in errors">
					{{error}}
				</li>
			</ul>
		</div>
		
	</div>
</template>
