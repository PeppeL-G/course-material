<script>

import jwtDecode from 'jwt-decode'

export default {
	props: {
		user: Object,
	},
	data(){
		// Add "username" and "password" to the model,
		// so we can bind what the user types in the
		// <input> elements to these.
		return {
			username: "",
			password: "",
		}
	},
	methods: {
		handleSubmission(){
			
			const credentials = {
				username: this.username,
				password: this.password
			}
			
			fetch("http://localhost:8080/tokens", {
				method: "POST",
				headers: new Headers({
					"Content-Type": "application/json"
				}),
				body: JSON.stringify(credentials)
			}).then(response => {
				
				if(response.status == 200){
					
					response.json().then(body => {
						
						this.user.isLoggedIn = true
						this.user.accessToken = body.accessToken
						
						const info = jwtDecode(body.idToken)
						
						this.user.accountId = info.accountId
						this.user.username = info.username
						
					})
					
				}else if(response.status == 400){
					alert("Got 400") // TODO: Handle this better.
				}else if(response.status == 500){
					alert("Got 500") // TODO: Handler this better.
				}
				
			})
			
		}
	}
}
</script>

<template>
	<div class="page">
		<h1>Login</h1>
		<p>This is the login page!</p>
		<div>
			Username: <input type="text" v-model="username">
		</div>
		<div>
			Password: <input type="password" v-model="password">
		</div>
		<button @click="handleSubmission">Login</button>
	</div>
</template>

<style scoped>

.page{
	background-color: lime;
}

</style>
