<script>
	export default {
		data(){
			return {
				accounts: [],
				errors: []
			}
		},
		mounted(){
			fetch("http://localhost:8080/accounts").then(response => {
				
				if(response.status == 200){
					
					response.json().then(accounts => {
						this.accounts = accounts
					})
					
				}else if(response.status == 500){
					this.errors.push("Server couldn't send back all accounts")
				}
				
			})
		},
	}
</script>

<template>
	<div class="page">
		<h1>Accounts</h1>
		
		<div v-if="errors.length == 0">
			<p>Here are all the accounts!</p>
			<ul>
				<li v-for="account in accounts">
					{{account.id}} {{account.username}}
				</li>
			</ul>
		</div>
		
		<div v-else>
			<p>Can't show the ads because:</p>
			<ul>
				<li v-for="error in errors">
					{{error}}
				</li>
			</ul>
		</div>
		
	</div>
</template>
