const express = require('express')
const db = require('../db.js')

const MOVIE_TITLE_MAX_LENGTH = 100

const router = express.Router()

router.get('/', function(request, response){
	
	db.getAllMovies(function(error, movies){
		
		const errorMessages = []
		
		if(error){
			errorMessages.push("Internal server error")
		}
		
		const model = {
			errorMessages,
			movies,
		}
		
		response.render('movies.hbs', model)
		
	})
	
})

// GET /movies/create
router.get("/create", function(request, response){
	response.render("create-movie.hbs")
})

router.post("/create", function(request, response){
	
	const title = request.body.title
	const grade = parseInt(request.body.grade, 10)
	
	const errorMessages = []
	
	if(title == ""){
		errorMessages.push("Title can't be empty")
	}else if(MOVIE_TITLE_MAX_LENGTH < title.length){
		errorMessages.push("Title may be at most "+MOVIE_TITLE_MAX_LENGTH+" characters long")
	}
	
	if(isNaN(grade)){
		errorMessages.push("You did not enter a number for the grade")
	}else if(grade < 0){
		errorMessages.push("Grade may not be negative")
	}else if(10 < grade){
		errorMessages.push("Grade may at most be 10")
	}
	
	if(!request.session.isLoggedIn){
		errorMessages.push("Not logged in")
	}
	
	if(errorMessages.length == 0){
		
		db.createMovie(title, grade, function(error){
			
			if(error){
				
				errorMessages.push("Internal server error")
				
				const model = {
					errorMessages,
					title,
					grade
				}
				
				response.render('create-movie.hbs', model)
				
			}else{
				
				response.redirect("/movies")
				
			}
			
		})
		
	}else{
		
		const model = {
			errorMessages,
			title,
			grade
		}
		
		response.render('create-movie.hbs', model)
		
	}
	
})

// GET /movies/1
// GET /movies/2
router.get("/:id", function(request, response){
	
	const id = request.params.id
	
	db.getMovieById(id, function(error, movie){
		
		const model = {
			movie,
		}
		
		response.render('movie.hbs', model)
		
	})
	
})

module.exports = router