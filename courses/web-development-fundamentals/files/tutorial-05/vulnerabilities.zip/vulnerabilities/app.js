const express = require('express')
const expressHandlebars = require('express-handlebars')
const sqlite3 = require('sqlite3')

// Setup everything.
const app = express()

app.engine('hbs', expressHandlebars.engine({
	defaultLayout: 'main.hbs',
}))

app.use(express.urlencoded({
	extended: false
}))

const db = new sqlite3.Database("the-database.db")

// The start page.
app.get('/', function(request, response){
	response.render('start.hbs')
})




// The guestbook.
const guestbookPosts = [{
	text: "Alice was here.",
	color: "aqua"
}]

// CSS injection in the handlebars file.
app.get('/guestbook', function(request, response){
	
	const model = {
		guestbookPosts
	}
	
	response.render('guestbook.hbs', model)
	
})

app.post('/guestbook', function(request, response){
	
	const text = request.body.text
	const color = request.body.color
	
	const guestbookPost = {
		text,
		color,
	}
	
	guestbookPosts.push(guestbookPost)
	
	response.redirect('/guestbook')
	
})





// The blog.
app.get('/blog', function(request, response){
	
	const query = "SELECT * FROM blogposts WHERE isPublished = 1"
	
	db.all(query, function(error, blogposts){
		
		const model = {
			blogposts
		}
		
		response.render('blogposts.hbs', model)
		
	})
	
})

app.get('/blog/:id', function(request, response){
	
	const id = request.params.id
	
	// SQL injection
	const query = "SELECT * FROM blogposts WHERE isPublished = 1 AND id = "+id
	
	db.get(query, function(error, blogpost){
		
		const model = {
			blogpost
		}
		
		response.render('blogpost.hbs', model)
		
	})
	
})



app.listen(8080)