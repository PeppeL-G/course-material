package se.ju.larpet.todoapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

var retrofit = Retrofit.Builder()
    .baseUrl("https://jsonplaceholder.typicode.com/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()

val dataService = retrofit.create(DataService::class.java)

interface DataService {
    @GET("todos")
    suspend fun getAllToDos(): List<ToDo>
}