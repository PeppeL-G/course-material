package se.ju.larpet.todoapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.*
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import se.ju.larpet.todoapp.databinding.FragmentListToDosBinding
import se.ju.larpet.todoapp.databinding.ItemViewToDoBinding


class ListToDosFragment : Fragment() {

    lateinit var binding: FragmentListToDosBinding
    val viewModel: MyViewModel by viewModels()
    val activityViewModel: MainActivityViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentListToDosBinding.inflate(layoutInflater, container, false).run {
        binding = this
        root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.toDos.observe(viewLifecycleOwner) {
            if(it != null){

                binding.recyclerView.post {

                    binding.recyclerView.apply {
                        layoutManager = LinearLayoutManager(context)
                        adapter = MyAdapter(it, activityViewModel)
                    }

                    binding.progressBar.visibility = View.GONE

                }

            }
        }

    }

    companion object {
        fun newInstance() = ListToDosFragment()
    }
}

class MyViewModel : ViewModel(){

    val toDos = MutableLiveData<List<ToDo>?>()

    init {

        viewModelScope.launch(Dispatchers.IO) {

            val fetchedToDos = dataService.getAllToDos()

            toDos.postValue(fetchedToDos)

        }

    }


}

class MyViewHolder(val binding: ItemViewToDoBinding) : RecyclerView.ViewHolder(binding.root)

class MyAdapter(
        val toDos: List<ToDo>,
        val activityViewModel: MainActivityViewModel
        ) : RecyclerView.Adapter<MyViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = MyViewHolder(
        ItemViewToDoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
    )

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val toDo = toDos[position]

        holder.binding.titleTextView.text = toDo.title

        // TODO: Don't create so many click listeners, using one should be enough.
        holder.binding.titleTextView.setOnClickListener {
            activityViewModel.clickedToDoId.value = toDo.id
        }


    }

    override fun getItemCount() = toDos.size

}