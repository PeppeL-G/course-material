package se.ju.larpet.todoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ViewToDoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_to_do)

        val toDoId = intent.getIntExtra(EXTRA_TO_DO_ID, 0)

        if(savedInstanceState == null) {

            supportFragmentManager.beginTransaction()
                .add(R.id.frame_layout, ViewToDoFragment.newInstance(toDoId))
                .commit()

        }

    }

    companion object {
        const val EXTRA_TO_DO_ID = "TO_DO_ID"
    }

}