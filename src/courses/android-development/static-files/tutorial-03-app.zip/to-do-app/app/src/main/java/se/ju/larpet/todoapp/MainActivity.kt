package se.ju.larpet.todoapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import se.ju.larpet.todoapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    val viewModel: MainActivityViewModel by viewModels()
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        viewModel.clickedToDoId.observe(this) {

            // Check if we are in portrait or landscape mode.
            if(binding.frameLayout == null){
                startActivity(
                    Intent(
                            this,
                            ViewToDoActivity::class.java
                    ).apply {
                        putExtra(ViewToDoActivity.EXTRA_TO_DO_ID, it)
                    }
                )
            }else{

                // Instead of creating a new fragment instance, you could update the arguments
                    //  and the GUI in the existing fragment instance.
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.frame_layout, ViewToDoFragment.newInstance(it))
                    .commit()

            }

        }

    }

}

// Let the ListToDosFragment notify the activity when the user clicks on an item
// by assigning clickedToDoId the id of the ToDo the user clicked on.
class MainActivityViewModel : ViewModel(){
    val clickedToDoId = MutableLiveData(-1)
}