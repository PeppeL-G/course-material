package se.ju.larpet.todoapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

private const val ARG_TO_DO_ID = "TO_DO_ID"

class ViewToDoFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_view_to_do, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // TODO: Fetch ToDo item from server, store it in a viewModel, etc.
        val toDoId = requireArguments().getInt(ARG_TO_DO_ID)

        view.findViewById<TextView>(R.id.title_text_view).text = "Id: $toDoId"

    }

    companion object {
        fun newInstance(toDoId: Int) =
            ViewToDoFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_TO_DO_ID, toDoId)
                }
            }
    }
}