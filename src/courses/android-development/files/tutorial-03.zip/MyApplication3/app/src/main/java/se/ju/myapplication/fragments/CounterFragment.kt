package se.ju.myapplication.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import se.ju.myapplication.R

class CounterFragment : Fragment() {

    // TODO: Use a ViewModel instead?
    var startValue = 0
    var currentValue = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO: Don't hardcode keys, put them in descriptive constant.
        startValue = requireArguments().getInt("startValue")

        currentValue =
            savedInstanceState?.getInt("BUNDLE_CURRENT_VALUE") ?:
            startValue

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(
        R.layout.fragment_counter,
        container,
        false
    )!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // TODO: button.text = "$currentValue" hardcoded at multiple places.
        val button = view.findViewById<Button>(R.id.counter_button)
        button.text = "$currentValue"
        button.setOnClickListener {
            currentValue += 1
            button.text = "$currentValue"
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("BUNDLE_CURRENT_VALUE", currentValue)
    }

    companion object {
        fun newInstance(startValue: Int) = CounterFragment().apply {
            arguments = Bundle().apply{
                putInt("startValue", startValue)
            }
        }
    }

}