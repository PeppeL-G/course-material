package se.ju.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import se.ju.myapplication.databinding.ActivityCountDownWithFragmentBinding
import se.ju.myapplication.fragments.CounterFragment

class CountDownWithFragmentActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bindings = ActivityCountDownWithFragmentBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        if(savedInstanceState == null) {

            val counterFragment1 = CounterFragment.newInstance(5)
            val counterFragment2 = CounterFragment.newInstance(8)

            supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container_1, counterFragment1)
                .add(R.id.fragment_container_2, counterFragment2)
                .commit()

        }

    }

}