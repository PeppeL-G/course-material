package se.ju.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import se.ju.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bindings = ActivityMainBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        bindings.activityEditTextButton.setOnClickListener {
            startActivity(
                Intent(this, EditTextActivity::class.java)
            )
        }

        bindings.activityCounterButton.setOnClickListener {
            startActivity(
                Intent(this, CounterActivity::class.java)
            )
        }

        bindings.activityCountDownWithFragmentButton.setOnClickListener {
            startActivity(
                Intent(this, CountDownWithFragmentActivity::class.java)
            )
        }

        bindings.activityBottomNavigationButton.setOnClickListener {
            startActivity(
                Intent(this, BottomNavigationActivity::class.java)
            )
        }

        bindings.showPopupButton.setOnClickListener {
            requestPermissions(
                listOf(
                    android.Manifest.permission.READ_CONTACTS
                ).toTypedArray(),
                1234
            )
        }

        Log.d("MainActivity", "onCreate()")

    }

    override fun onStart() {
        super.onStart()
        Log.d("MainActivity", "onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d("MainActivity", "onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d("MainActivity", "onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d("MainActivity", "onStop()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MainActivity", "onDestroy()")
    }

}