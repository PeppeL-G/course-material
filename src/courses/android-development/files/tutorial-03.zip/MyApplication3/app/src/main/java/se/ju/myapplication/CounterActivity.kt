package se.ju.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import se.ju.myapplication.databinding.ActivityCounterBinding

class CounterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val viewModel: CounterViewModel by viewModels()
        val bindings = ActivityCounterBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        bindings.counterButton.text = "${viewModel.counter}"
        bindings.counterButton.setOnClickListener {
            viewModel.counter += 1
            bindings.counterButton.text = "${viewModel.counter}"
        }

    }

}

class CounterViewModel : ViewModel(){
    var counter = 0
}