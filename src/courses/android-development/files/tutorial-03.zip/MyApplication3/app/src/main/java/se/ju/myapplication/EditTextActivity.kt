package se.ju.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import se.ju.myapplication.databinding.ActivityEditTextBinding

class EditTextActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bindings = ActivityEditTextBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        bindings.textView.text = "${Math.random()}"

    }

}