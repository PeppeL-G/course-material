package se.ju.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import se.ju.myapplication.databinding.ActivityBottomNavigationBinding
import se.ju.myapplication.fragments.AboutFragment
import se.ju.myapplication.fragments.CounterFragment
import se.ju.myapplication.fragments.HomeFragment

class BottomNavigationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bindings = ActivityBottomNavigationBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        if(savedInstanceState == null) {

            supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container_view, HomeFragment.newInstance())
                .commit()

        }

        // TODO: Probably want to use the same CounterFragment all the time,
        // so it doesn't restart on 5. Store it in an instance variable?
        // But then you also need to handle runtime configuration changes :/
        // One can store multiple fragments in the fragment manager, but
        // only show one at a time. Is that the best solution?
        bindings.homeButton.setOnClickListener {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.fragment_container_view, CounterFragment.newInstance(5))
                .commit()
        }

        bindings.aboutButton.setOnClickListener {
            // TODO: Code like this has been written multiple times. Refactor.
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.fragment_container_view, AboutFragment.newInstance())
                .commit()
        }

    }

}