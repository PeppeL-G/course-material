package se.ju.larpet.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val countButton = findViewById<Button>(R.id.count_button)
        val calculatorButton = findViewById<Button>(R.id.calculator_button)
        val clockButton = findViewById<Button>(R.id.clock_button)

        countButton.setOnClickListener {
            val intent = Intent(
                this,
                CounterActivity::class.java
            )
            startActivity(intent)
        }
        calculatorButton.setOnClickListener {

        }
        clockButton.setOnClickListener {

        }

    }


}