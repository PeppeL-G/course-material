package se.ju.larpet.myapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import se.ju.larpet.myapplication.databinding.ActivityCounterBinding

class CounterActivity: AppCompatActivity() {

    var counterValue = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val viewBinding = ActivityCounterBinding.inflate(layoutInflater)

        setContentView(viewBinding.root)

        viewBinding.counterButton.text = counterValue.toString()

        viewBinding.counterButton.setOnClickListener {
            counterValue += 1
            viewBinding.counterButton.text = counterValue.toString()
        }

    }

}