package se.ju.myapplication.countdown

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.ViewModel
import se.ju.myapplication.R
import se.ju.myapplication.databinding.ActivityCountDownBinding

class CountDownActivityViewModel : ViewModel(){

}

class CountDownActivity : AppCompatActivity() {

    val viewModel: CountDownActivityViewModel by viewModels()
    lateinit var bindings : ActivityCountDownBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bindings = ActivityCountDownBinding.inflate(layoutInflater)

        setContentView(bindings.root)

        if(savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .add(
                    R.id.fragment_container_view,
                    CountDownFragment.newInstance(10)
                )
                .commitNow()
        }

        val fragment = supportFragmentManager.findFragmentById(
            R.id.fragment_container_view
        ) as CountDownFragment

        fragment.viewModel.counter.observe(this){
            if(fragment.viewModel.counter.value == 0){
                bindings.textView.text = "It's zero!"
            }
        }

    }

}