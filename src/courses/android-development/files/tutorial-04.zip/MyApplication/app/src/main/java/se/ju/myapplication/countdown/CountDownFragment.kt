package se.ju.myapplication.countdown

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import se.ju.myapplication.databinding.FragmentCountDownBinding

class CountDownModel : ViewModel(){

    val counter = MutableLiveData(-1)

    fun initialize(startValue: Int){

        counter.value = startValue

        viewModelScope.launch(Dispatchers.Default) {

            while(1 <= counter.value!!) {

                delay(1000)

                withContext(Dispatchers.Main) {
                    counter.value = counter.value!! - 1
                }

                Log.d(
                    "CounterDecremented",
                    "Counter's new value: ${counter.value}"
                )

            }

        }

    }

}

private const val ARG_START_VALUE = "START_VALUE"

class CountDownFragment : Fragment() {

    val viewModel: CountDownModel by viewModels()
    lateinit var bindings: FragmentCountDownBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if(savedInstanceState == null) {

            requireArguments().run {

                viewModel.initialize(
                    getInt(ARG_START_VALUE)
                )

            }

        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentCountDownBinding.inflate(
        layoutInflater,
        container,
        false
    ).run{
        bindings = this
        bindings.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.counter.observe(viewLifecycleOwner){
            bindings.countDownButton.text = "${viewModel.counter.value}"
        }

    }

    companion object {
        fun newInstance(startValue: Int) =
            CountDownFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_START_VALUE, startValue)
                }
            }
    }

}