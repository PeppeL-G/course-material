package se.ju.larpet.andtest445

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts

class AskForPermissionFragment : Fragment() {

    val askForPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ){
        if(it){
            val activity = activity as MainActivity
            activity.updateFragment()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_ask_for_permission, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.grant_permission_button).setOnClickListener {

            askForPermission.launch(ACCESS_FINE_LOCATION)

        }

    }

    companion object {
        fun newInstance() = AskForPermissionFragment()
    }

}