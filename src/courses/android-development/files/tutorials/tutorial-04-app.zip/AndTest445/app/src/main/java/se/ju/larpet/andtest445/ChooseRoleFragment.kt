package se.ju.larpet.andtest445

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

class ChooseRoleFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_choose_role, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.client_button).setOnClickListener {
            val activity = activity as MainActivity
            activity.role = Role.CLIENT
            activity.updateFragment()
        }

        view.findViewById<Button>(R.id.server_button).setOnClickListener {
            val activity = activity as MainActivity
            activity.role = Role.SERVER
            activity.updateFragment()
        }

    }

    companion object {
        fun newInstance() = ChooseRoleFragment()
    }

}