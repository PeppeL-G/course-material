package se.ju.larpet.andtest445

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.os.IBinder
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.concurrent.thread

val uuid = UUID.fromString("1374c9d1-f8a2-4d33-a021-317cc289f469")

class ChatService : Service() {

    lateinit var socketToOther : BluetoothSocket

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        when(intent!!.action){
            ACTION_START_SERVER -> startServer()
            ACTION_START_CLIENT -> startClient(
                intent.getParcelableExtra<BluetoothDevice>(EXTRA_BLUETOOTH_DEVICE)!!
            )
            ACTION_SEND_MESSAGE -> sendMessage(
                intent.getStringExtra(EXTRA_MESSAGE)!!
            )
        }

        return START_NOT_STICKY

    }

    private fun sendMessage(message: String) {

        thread {
            socketToOther.outputStream.write(message.toByteArray(StandardCharsets.UTF_8))
        }

    }

    private fun startClient(device: BluetoothDevice) {

        socketToOther = device.createRfcommSocketToServiceRecord(uuid)

        socketToOther.connect()

        applicationContext.sendBroadcast(
            Intent(ACTION_CONNECTION_ESTABLISHED)
        )

        thread {
            listenForInput()
        }

    }

    fun startServer(){

        val adapter = BluetoothAdapter.getDefaultAdapter()

        val server = adapter.listenUsingRfcommWithServiceRecord("Chat", uuid)

        thread {

            socketToOther = server.accept()

            applicationContext.sendBroadcast(
                Intent(ACTION_CONNECTION_ESTABLISHED)
            )

            listenForInput()

        }

    }

    private fun listenForInput() {

        while(true) {

            val bytes = ByteArray(512)
            val numberOfBytesRead = socketToOther.inputStream.read(bytes)
            val message = String(bytes, 0, numberOfBytesRead, StandardCharsets.UTF_8)

            applicationContext.sendBroadcast(
                Intent(ACTION_MESSAGE_RECEIVED).apply {
                    putExtra(EXTRA_MESSAGE, message)
                }
            )

        }

    }

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }

    companion object {

        const val ACTION_START_SERVER = "ACTION_START_SERVER"

        const val ACTION_CONNECTION_ESTABLISHED = "ACTION_CONNECTION_ESTABLISHED"

        const val ACTION_START_CLIENT = "ACTION_START_CLIENT"
        const val EXTRA_BLUETOOTH_DEVICE = "EXTRA_BLUETOOTH_DEVICE"

        const val ACTION_SEND_MESSAGE = "ACTION_SEND_MESSAGE"
        const val EXTRA_MESSAGE = "EXTRA_MESSAGE"

        const val ACTION_MESSAGE_RECEIVED = "ACTION_MESSAGE_RECEIVED"



    }

}