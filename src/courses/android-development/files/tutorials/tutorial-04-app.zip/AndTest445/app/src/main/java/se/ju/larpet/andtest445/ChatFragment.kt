package se.ju.larpet.andtest445

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class ChatMessage(
    val senderName: String,
    val message: String
)

class ChatFragment : Fragment() {

    val newChatMessageReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {

            val message = intent!!.getStringExtra(ChatService.EXTRA_MESSAGE)!!

            chatMessages.add(ChatMessage("Other", message))
            recyclerView.adapter!!.notifyDataSetChanged()

        }

    }

    val chatMessages = mutableListOf(
        ChatMessage("Other", "abc"),
        ChatMessage("Me", "123"),
    )

    lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requireContext().registerReceiver(
            newChatMessageReceiver,
            IntentFilter(ChatService.ACTION_MESSAGE_RECEIVED)
        )

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_chat, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = ChatMessageAdapter(chatMessages)

        view.findViewById<Button>(R.id.send_button).setOnClickListener {

            val message = view.findViewById<EditText>(R.id.edit_text).text.toString()

            chatMessages.add(
                ChatMessage("Me", message)
            )

            recyclerView.adapter!!.notifyDataSetChanged()

            requireContext().startService(
                Intent(requireContext(), ChatService::class.java).apply{
                    action = ChatService.ACTION_SEND_MESSAGE
                    putExtra(ChatService.EXTRA_MESSAGE, message)
                }
            )

        }

    }

    companion object {
        fun newInstance() = ChatFragment()
    }

}

class ChatMessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
    val textView = itemView.findViewById<TextView>(R.id.text_view)
}

class ChatMessageAdapter(
    val chatMessages: MutableList<ChatMessage>
) : RecyclerView.Adapter<ChatMessageViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ChatMessageViewHolder(
        LayoutInflater.from(parent.context).inflate(
            R.layout.item_view_chat_message,
            parent,
            false
        )
    )

    override fun onBindViewHolder(holder: ChatMessageViewHolder, position: Int) {

        val chatMessage = chatMessages[position]
        holder.textView.text = "${chatMessage.senderName}: ${chatMessage.message}"

    }

    override fun getItemCount() = chatMessages.size

}