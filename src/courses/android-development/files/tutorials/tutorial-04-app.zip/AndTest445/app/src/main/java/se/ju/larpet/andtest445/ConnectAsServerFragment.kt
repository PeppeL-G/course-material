package se.ju.larpet.andtest445

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import se.ju.larpet.andtest445.ChatService.Companion.ACTION_START_SERVER

class ConnectAsServerFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requireContext().startService(
            Intent(requireContext(), ChatService::class.java).apply {
                action = ACTION_START_SERVER
            }
        )

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_connect_as_server, container, false)!!

    lateinit var makeVisibleButton: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        makeVisibleButton = view.findViewById<Button>(R.id.make_visible_button)
        makeVisibleButton.setOnClickListener {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
            )
        }

    }

    companion object {
        fun newInstance() = ConnectAsServerFragment()
    }

}