package se.ju.larpet.andtest445

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.channels.BroadcastChannel

class ConnectAsClientFragment : Fragment() {

    val foundDevices = mutableListOf<BluetoothDevice>()

    val foundDeviceReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {

            val bluetoothDevice = intent!!.getParcelableExtra<BluetoothDevice>(
                BluetoothDevice.EXTRA_DEVICE
            )!!

            foundDevices.add(bluetoothDevice)
            recyclerView.adapter!!.notifyDataSetChanged()

        }
    }

    lateinit var recyclerView: RecyclerView
    lateinit var startDiscoveryButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requireContext().registerReceiver(
            foundDeviceReceiver,
            IntentFilter(BluetoothDevice.ACTION_FOUND)
        )

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_connect_as_client, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        startDiscoveryButton = view.findViewById(R.id.start_discovery_button)
        startDiscoveryButton.setOnClickListener {
            BluetoothAdapter.getDefaultAdapter().startDiscovery()
        }

        recyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.run {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = BluetoothDeviceAdapter(foundDevices)
        }

    }

    companion object {
        fun newInstance() = ConnectAsClientFragment()
    }

}

class BluetoothDeviceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
    val textView = itemView.findViewById<TextView>(R.id.text_view)
}

class BluetoothDeviceAdapter(
    val bluetoothDevices: MutableList<BluetoothDevice>
    ) : RecyclerView.Adapter<BluetoothDeviceViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = BluetoothDeviceViewHolder(
        LayoutInflater.from(parent.context).inflate(
            R.layout.item_view_bluetooth_device,
            parent,
            false
        )
    )

    override fun onBindViewHolder(holder: BluetoothDeviceViewHolder, position: Int) {

        val device = bluetoothDevices[position]
        holder.textView.text = "${device.name}"
        holder.textView.setOnClickListener {
            holder.textView.context.startService(
                Intent(holder.textView.context, ChatService::class.java).apply {
                    action = ChatService.ACTION_START_CLIENT
                    putExtra(ChatService.EXTRA_BLUETOOTH_DEVICE, device)
                }
            )
            BluetoothAdapter.getDefaultAdapter().cancelDiscovery()
        }

    }

    override fun getItemCount() = bluetoothDevices.size

}