package se.ju.larpet.andtest445

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

class EnableBluetoothFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(R.layout.fragment_enable_bluetooth, container, false)!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.enable_bluetooth_button).setOnClickListener {
            requireContext().startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            )
        }

    }

    companion object {
        fun newInstance() = EnableBluetoothFragment()
    }

}