package se.ju.larpet.andtest445

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager.PERMISSION_DENIED
import android.content.pm.PackageManager.PERMISSION_GRANTED
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel

enum class Role {
    NOT_CHOSEN,
    CLIENT,
    SERVER
}

class MainActivity : AppCompatActivity() {

    val bluetoothChangedReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            updateFragment()
        }
    }

    val connectionEstablishedReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            isConnected = true
            updateFragment()
        }
    }

    var isConnected = false
    var role = Role.NOT_CHOSEN

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            updateFragment()
        }

        registerReceiver(
            bluetoothChangedReceiver,
            IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
        )

        registerReceiver(
            connectionEstablishedReceiver,
            IntentFilter(ChatService.ACTION_CONNECTION_ESTABLISHED)
        )

    }

    override fun onDestroy() {
        super.onDestroy()

        unregisterReceiver(bluetoothChangedReceiver)
        unregisterReceiver(connectionEstablishedReceiver)

    }

    fun updateFragment(){

        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        val fragment = when {
            bluetoothAdapter == null -> NoBluetoothFragment.newInstance()
            !bluetoothAdapter.isEnabled -> EnableBluetoothFragment.newInstance()
            ContextCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) == PERMISSION_DENIED -> AskForPermissionFragment.newInstance()
            isConnected -> ChatFragment.newInstance()
            role == Role.NOT_CHOSEN -> ChooseRoleFragment.newInstance()
            role == Role.CLIENT -> ConnectAsClientFragment.newInstance()
            role == Role.SERVER -> ConnectAsServerFragment.newInstance()
            else -> ConnectAsServerFragment.newInstance()
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_layout, fragment)
            .commit()

    }



}