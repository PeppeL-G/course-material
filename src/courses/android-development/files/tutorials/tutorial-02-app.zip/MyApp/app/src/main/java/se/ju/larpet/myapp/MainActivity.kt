package se.ju.larpet.myapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.os.bundleOf
import se.ju.larpet.myapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        if(savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .add(R.id.frame_layout, CountUpFragment(), TAG_FRAGMENT_COUNT_UP)
                .add(R.id.frame_layout, CountDownFragment.newInstance(10), TAG_FRAGMENT_COUNT_DOWN)
                .add(R.id.frame_layout, NumbersFragment(), TAG_FRAGMENT_NUMBERS)
                .commitNow()
            changeToFragment(TAG_FRAGMENT_COUNT_UP)
        }

        binding.countUpButton.setOnClickListener {
            changeToFragment(TAG_FRAGMENT_COUNT_UP)
        }

        binding.countDownButton.setOnClickListener {
            changeToFragment(TAG_FRAGMENT_COUNT_DOWN)
        }

        binding.numbersButton.setOnClickListener {
            changeToFragment(TAG_FRAGMENT_NUMBERS)
        }

    }

    fun changeToFragment(fragment_tag: String){

        with(supportFragmentManager.beginTransaction()){

            for(fragment in supportFragmentManager.fragments){
                hide(fragment)
            }

            show(supportFragmentManager.findFragmentByTag(fragment_tag)!!)

            commit()

        }


    }

    companion object {
        const val TAG_FRAGMENT_COUNT_UP = "TAG_FRAGMENT_COUNT_UP"
        const val TAG_FRAGMENT_COUNT_DOWN = "TAG_FRAGMENT_COUNT_DOWN"
        const val TAG_FRAGMENT_NUMBERS = "TAG_FRAGMENT_NUMBERS"
    }

}