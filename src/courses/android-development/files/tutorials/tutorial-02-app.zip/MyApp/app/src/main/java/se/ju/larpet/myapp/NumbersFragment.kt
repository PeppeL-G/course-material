package se.ju.larpet.myapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import se.ju.larpet.myapp.databinding.FragmentNumbersBinding



class NumbersFragment : Fragment() {

    lateinit var binding: FragmentNumbersBinding

    val numbers = mutableListOf(5, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3, 3, 7, 6, 3)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentNumbersBinding.inflate(inflater, container, false).run {
        binding = this
        root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding.recyclerView) {
            layoutManager = LinearLayoutManager(context)
            adapter = MyAdapter(numbers)
        }

        // TODO, listen for clicks on the Add button, add a number to the list and then
        // tell the adapter that the list has changed (e.g. notifyDataSetChanged).

    }

}

class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
    val textView = itemView.findViewById<TextView>(R.id.text_view)
}

class MyAdapter(val numbers: List<Int>) : RecyclerView.Adapter<MyViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.list_item_number,
                parent,
                false
            )
        )

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val number = numbers[position]
        holder.textView.text = "Hello $number" // TODO, Use string resources! Goes for the layouts in the XML files as well.
    }

    override fun getItemCount() = numbers.size

}