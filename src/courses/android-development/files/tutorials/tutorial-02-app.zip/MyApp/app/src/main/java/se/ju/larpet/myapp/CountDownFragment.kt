package se.ju.larpet.myapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import se.ju.larpet.myapp.databinding.FragmentCountDownBinding
import se.ju.larpet.myapp.databinding.FragmentCountUpBinding

class CountDownFragment : Fragment() {

    var counter = 0
    lateinit var binding: FragmentCountDownBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if(savedInstanceState != null){
            counter = savedInstanceState.getInt(STATE_COUNTER)
        }else{
            counter = arguments!!.getInt(ARG_START_VALUE)
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentCountDownBinding.inflate(inflater, container, false).run {
        binding = this
        root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.textView.text = "$counter"

        binding.decrementButton.setOnClickListener {
            counter--
            binding.textView.text = "$counter"
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_COUNTER, counter)
    }

    companion object {

        const val STATE_COUNTER = "STATE_COUNTER"
        const val ARG_START_VALUE = "ARG_START_VALUE"

        fun newInstance(startValue: Int) = CountDownFragment().apply{
            arguments = bundleOf(ARG_START_VALUE to startValue)
        }

    }

}