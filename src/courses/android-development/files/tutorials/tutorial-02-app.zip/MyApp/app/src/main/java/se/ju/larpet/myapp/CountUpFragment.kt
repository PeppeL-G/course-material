package se.ju.larpet.myapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import se.ju.larpet.myapp.databinding.FragmentCountUpBinding

class CountUpFragment : Fragment() {

    var counter = 0
    lateinit var binding: FragmentCountUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if(savedInstanceState != null){
            counter = savedInstanceState.getInt(STATE_COUNTER)
        }

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentCountUpBinding.inflate(inflater, container, false).run {
        binding = this
        root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.textView.text = "$counter"

        binding.incrementButton.setOnClickListener {
            counter++
            binding.textView.text = "$counter"
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_COUNTER, counter)
    }

    companion object {
        const val STATE_COUNTER = "STATE_COUNTER"
    }

}