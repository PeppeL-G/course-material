package se.ju.larpet.andtest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.TextView

class CountDownActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_count_down)

        var countDown = 60

        val textView = findViewById<TextView>(R.id.textView)
        textView.text = "$countDown"

        val handler = Handler(Looper.myLooper()!!)

        val runnable = object: Runnable{
            override fun run() {
                countDown -= 1
                textView.text = "$countDown"
                handler.postDelayed(this, 1000)
                Log.d("CountDown", "Tick")
            }
        }

        handler.postDelayed(runnable, 1000)

        // Need to call handler.removeCallbacks(runnable) in onDestroy() if
        // we start the handler.postDelayed()-recursion in this method.

    }
}