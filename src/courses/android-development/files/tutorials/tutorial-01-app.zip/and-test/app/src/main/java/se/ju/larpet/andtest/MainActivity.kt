package se.ju.larpet.andtest

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val firstButton = findViewById<Button>(R.id.first_button)
        val secondButton = findViewById<Button>(R.id.second_button)
        val thirdButton = findViewById<Button>(R.id.third_button)

        firstButton.setOnClickListener {
            startActivity(
                Intent(this, SecondActivity::class.java)
            )
        }

        secondButton.setOnClickListener {
            startActivity(
                Intent(this, CountDownActivity::class.java)
            )
        }

        thirdButton.setOnClickListener {
            startActivity(
                Intent(this, LoginActivity::class.java)
            )
        }





        Log.d("Main", "onCreate")

    }

    override fun onStart() {
        super.onStart()
        Log.d("Main", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Main", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Main", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Main", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Main", "onDestroy")
    }

}