const express = require('express')
const expressHandlebars = require('express-handlebars')
const sqlite3 = require('sqlite3')

const db = new sqlite3.Database("my-website-db.db")

db.run(`
	CREATE TABLE IF NOT EXISTS humans (
		id INTEGER PRIMARY KEY,
		name TEXT,
		age INTEGER,
		url TEXT
	)
`)

const app = express()

app.use(
	express.static('public')
)

app.engine('hbs', expressHandlebars.engine({
	defaultLayout: "main.hbs"
}))

// GET /
app.get('/', function(request, response){
	response.render("start.hbs")
})

app.get('/about', function(request, response){
	response.render("about.hbs")
})

app.get("/contact", function(request, response){
	response.render("contact.hbs")
})

app.get("/humans", function(request, response){
	
	const query = "SELECT * FROM humans"
	
	db.all(query, function(error, humans){
		
		const model = {
			humans: humans
		}
		
		response.render("humans.hbs", model)
		
	})
	
})

// /humans/1
// /humans/2
app.get("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "SELECT * FROM humans WHERE id = ?"
	const values = [id]
	
	db.get(query, values, function(error, human){
		
		const model = {
			human: human
		}
		
		response.render("human.hbs", model)
	
	})
	
	
})

app.listen(8080)