# Run instructions
1. Install Node.js (version XXX).
2. Clone the repository. `git clone ...`
3. In the project folder, run: `node app.js`
