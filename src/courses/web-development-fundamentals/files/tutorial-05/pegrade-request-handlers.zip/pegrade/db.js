const sqlite3 = require('sqlite3')

const db = new sqlite3.Database("pegrade-database.db")

db.run(`
	CREATE TABLE IF NOT EXISTS movies (
		id INTEGER PRIMARY KEY,
		title TEXT,
		grade INTEGER
	)
`)

exports.getAllMovies = function(callback){
	
	const query = `SELECT * FROM movies`
	
	db.all(query, function(error, movies){
		callback(error, movies)
	})
	
}

exports.createMovie = function(title, grade, callback){
	
	const query = `
		INSERT INTO movies (title, grade) VALUES (?, ?)
	`
	const values = [title, grade]

	db.run(query, values, function(error){
		callback(error)
	})
	
}

exports.getMovieById = function(id, callback){
	
	const query = `SELECT * FROM movies WHERE id = ?`
	const values = [id]
	
	db.get(query, values, function(error, movie){
		callback(error, movie)
	})
	
}