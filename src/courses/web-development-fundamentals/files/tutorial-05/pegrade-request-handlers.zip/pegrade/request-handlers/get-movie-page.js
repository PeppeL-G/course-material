const db = require('../db.js')

module.exports = function(request, response){
	
	const id = request.params.id
	
	db.getMovieById(id, function(error, movie){
		
		const model = {
			movie,
		}
		
		response.render('movie.hbs', model)
		
	})
	
}