module.exports = function(request, response){
	response.render("create-movie.hbs")
}