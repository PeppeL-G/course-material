module.exports = function(request, response){
	response.render('start.hbs')
}