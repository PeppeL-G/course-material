const db = require('../db.js')

module.exports = function(request, response){
	
	db.getAllMovies(function(error, movies){
		
		const errorMessages = []
		
		if(error){
			errorMessages.push("Internal server error")
		}
		
		const model = {
			errorMessages,
			movies,
		}
		
		response.render('movies.hbs', model)
		
	})
	
}