const express = require('express')
const expressHandlebars = require('express-handlebars')
const expressSession = require('express-session')

const app = express()

app.engine('hbs', expressHandlebars.engine({
	defaultLayout: 'main.hbs',
}))

app.use(
	express.static('public')
)

app.use(
	express.urlencoded({
		extended: false
	})
)

app.use(
	expressSession({
		saveUninitialized: false,
		resave: false,
		secret: "fdgfdskdjslakfj"
	})
)

app.use(
	function(request, response, next){
		response.locals.session = request.session
		next()
	}
)

app.get('/', require('./request-handlers/get-start-page.js'))


app.get('/movies', require('./request-handlers/get-movies-page.js'))

// GET /movies/create
app.get("/movies/create", require('./request-handlers/get-create-movie-page.js'))

app.post("/movies/create", require('./request-handlers/create-movie.js'))

// GET /movies/1
// GET /movies/2
app.get("/movies/:id", require('./request-handlers/get-movie-page.js'))

app.get("/login", require('./request-handlers/get-login-page.js'))

app.post("/login", require('./request-handlers/login.js'))

app.listen(8080)