const express = require('express')
const handlebars = require('express-handlebars')
const sqlite3 = require('sqlite3')

const app = express()

app.engine('hbs', handlebars({
	defaultLayout: 'main.hbs',
	helpers: {
		bbcodeToHtml: function(bbcodeText){
			
			let htmlText = bbcodeText
			
			// Vulnerability: HTML not escaped.
			
			// Convert BBCode to HTML.
			htmlText = htmlText.replace(/\[b\]/gm, '<b>') // [b] <b>
			htmlText = htmlText.replace(/\[\/b\]/gm, '</b>') // [/b] </b>
			// Vulnerability: If [b] is used without a [/b]
			
			htmlText = htmlText.replace(
				/\[color=([\s\S]*?)\]([\s\S]*?)\[\/color\]/gm,
				function(match, color, textBetween){
					return `<span style="color: ${color}">${textBetween}</span>`
				}
			)
			// Vulnerability: [color=" onclick="alert('Hi!')]Click me![/color]
			
			return htmlText
			
		}
	}
}))

app.use(express.urlencoded({
	extended: false
}))



// The start page.
app.get('/', function(request, response){
	response.render('start.hbs')
})



// The guestbook.
const guestbookPosts = [{
	text: 'Great website!',
	color: 'red'
}]

app.get('/guestbook', function(request, response){
	
	const model = {
		guestbookPosts
	}
	
	response.render('guestbook.hbs', model)
	
})

app.post('/guestbook', function(request, response){
	
	// Vulnerabilities:
	//  - Not enough to use HTML validation attributes.
	//  - Can't assume all fields are really received.
	//  - Vulnerabilities in the bbcodeToHtml helper.
	
	const guestbookPost = {
		text: request.body.text,
		color: request.body.color
	}
	
	guestbookPosts.push(guestbookPost)
	
	response.redirect('/guestbook')
	
})





// The blog.
const db = new sqlite3.Database("the-database.db")

app.get('/blog', function(request, response){
	
	const query = "SELECT * FROM blogposts WHERE isPublished = 1"
	
	db.all(query, function(error, blogposts){
		
		const model = {
			blogposts
		}
		
		response.render('blogposts.hbs', model)
		
	})
	
})

app.get('/blog/:id', function(request, response){
	
	const id = request.params.id
	const query = "SELECT * FROM blogposts WHERE id = "+id
	
	// Vulnerabilities:
	//  - Send back any post, including those not published!
	//  - SQL injections.
	
	db.get(query, function(error, blogpost){
		
		const model = {
			blogpost
		}
		
		response.render('blogpost.hbs', model)
		
	})
	
})





// Login
// Only one admin should be able to login, so just one session needed, right?
// Store in global variable?
let isLoggedIn = false

app.get('/login', function(request, response){
	
	const model = {
		isLoggedIn
	}
	
	response.render('login.hbs', model)
	
})

app.post('/login', function(request, response){
	
	const username = request.body.username
	const password = request.body.password
	
	if(username == "Alice" && password == "abc123"){
		// Vulnerability: All users will be logged in!
		isLoggedIn = true
	}
	
	response.redirect('/login')
	
})



app.listen(3000)