const express = require('express')
const fs = require('fs')
const expressHandlebars = require('express-handlebars')

const app = express()

app.engine(".hbs", expressHandlebars({
	defaultLayout: "main.hbs"
}))

// GET /
app.get("/", function(request, response){
	response.render("home.hbs")
})

// GET /list-files
app.get("/list-files", function(request, response){
	
	fs.readdir("static-files", function(error, filenames){
		// Let us assume no error occurred.
		const model = {
			filenames
		}
		response.render("list-files.hbs", model)
	})
	
})

// GET /view-file?filename=hello.txt
app.get("/view-file", function(request, response){
	
	const filename = request.query.filename
	const filePath = "static-files/"+filename
	
	fs.readFile(filePath, 'utf8', function(error, fileContent){ 
		// Let us assume no error occurred.
		const model = {
			file: {
				name: filename,
				content: fileContent
			}
		}
		response.render('view-file.hbs', model)
	})
	
})

// GET /html-demo?code=HTML-CODE
app.get("/html-demo", function(request, response){
	
	const code = request.query.code
	
	const model = {
		code
	}
	
	response.render("html-demo.hbs", model)
	
})

app.listen(8080)