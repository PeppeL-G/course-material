const path = require('path')
const express = require('express')
const expressHandlebars = require('express-handlebars')

module.exports = function({variousRouter, accountRouter}){
	
	const app = express()

	// Setup express-handlebars.
	app.set('views', path.join(__dirname, 'views'))

	app.engine('hbs', expressHandlebars({
		extname: 'hbs',
		defaultLayout: 'main',
		layoutsDir: path.join(__dirname, 'layouts')
	}))

	// Handle static files in the public folder.
	app.use(express.static(path.join(__dirname, 'public')))

	app.use(express.urlencoded())

	// Attach all routers.
	app.use('/', variousRouter)
	app.use('/accounts', accountRouter)
	
	return app

}