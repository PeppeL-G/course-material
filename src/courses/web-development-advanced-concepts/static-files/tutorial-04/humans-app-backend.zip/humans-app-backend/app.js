const express = require('express')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')

const humans = [{
	id: 1,
	name: "Alice",
	age: 10
}, {
	id: 2,
	name: "Bob",
	age: 15
}]

function getValidationErrors(name, age){
	
	const validationErrors = []
	
	if(name.length < 3){
		validationErrors.push("Name must be at least 3 characters.")
	}
	
	if(age < 0){
		validationErrors.push("Age can't be negative.")
	}
	
	return validationErrors
	
}

const app = express()

app.use(function(request, response, next){
	console.log(request.method, request.url)
	next()
})

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
	extended: false
}))

app.get("/humans", function(request, response){
	
	// TODO: This will crash if Authorization header is missing of malformed.
	// TODO: Verify tokens is something you want to do in many requests,
	// so you want to make this part of the code re-useable somehow.
	const authorizationHeader = request.header("Authorization") // "Bearer XXX"
	const accessToken = authorizationHeader.substring("Bearer ".length) // "XXX"
	
	jwt.verify(accessToken, "sdfsdfsdfsdfsdfsdf", function(error, payload){
		
		if(error){
			response.status(401).end()
		}else{
			response.status(200).json(humans)
		}
		
	})
	
})

app.get("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const human = humans.find(h => h.id == id)
	
	if(human){
		response.status(200).json(human)
	}else{
		response.status(404).end()
	}
	
})

app.post("/humans", function(request, response){
	
	const name = request.body.name
	const age = request.body.age
	
	const errors = getValidationErrors(name, age)
	
	if(errors.length == 0){
		
		const id = humans[humans.length-1].id + 1
		
		const human = {
			id,
			name,
			age
		}
		
		humans.push(human)
		
		response.setHeader("Location", "/humans/"+id)
		response.status(201).json(human)
		
	}else{
		
		response.status(400).json(errors)
		
	}
	
})

app.delete("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const index = humans.findIndex(h => h.id == id)
	
	if(index == -1){
		response.status(404).end()
	}else{
		humans.splice(index, 1)
		response.status(204).end()
	}
	
})

app.put("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const newName = request.body.name
	const newAge = request.body.age
	
	const human = humans.find(h => h.id == id)
	
	if(!human){
		response.status(404).end()
	}else{
		
		const errors = getValidationErrors(newName, newAge)
		
		if(errors.length == 0){
			
			human.name = newName
			human.age = newAge
			
			response.status(204).end()
			
		}else{
			
			response.status(400).json(errors)
			
		}
		
	}
	
})

app.post("/tokens", function(request, response){
	
	// TODO: Verify grant_type is password.
	const grantType = request.body.grant_type
	const username = request.body.username
	const password = request.body.password
	
	if(username == "Alice" && password == "abc123"){
		
		// You probably want to put the user's id in the payload, so
		// you remember which account the user logged in to.
		const payload = {
			isLoggedIn: true
		}
		
		// TODO: Secret better put in constant.
		jwt.sign(payload, 'sdfsdfsdfsdfsdfsdf', function(err, token) {
			
			// TODO: Send back id token too per the Open ID Connect specification.
			response.status(200).json({
				"access_token": token
			})
			
		})
		
	}else{
		
		// TODO: Check OAuth 2.0 spec on what error to send back when.
		response.status(400).json({error: "something"})
		
	}
	
})

app.listen(3000)