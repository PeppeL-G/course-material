const express = require('express')
const petHandler = require('./pet-handler')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')

const app = express()

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
	extended: false
}))

app.get("/pets", function(request, response){
	
	// TODO: Extracting the payload is better put in a function
	// (preferably a middleware function).
	const authorizationHeader = request.get('authorization')
	const accessToken = authorizationHeader.substr("Bearer ".length)
	
	try {
		
		// TODO: Better to use jwt.verify asynchronously.
		const payload = jwt.verify(accessToken, serverSecret)
		
		// Use payload to implement authorization...
		
	}catch(e){
		response.status(401).end()
		return
	}
	
	petHandler.getAllPets(function(errors, pets){
		if(0 < errors.length){
			response.status(500).end()
		}else{
			response.status(200).json(pets)
		}
	})
	
})

app.get("/pets/:id", function(request, response){
	
	const id = request.params.id
	
	petHandler.getPetById(id, function(errors, pet){
		if(0 < errors.length){
			response.status(500).end()
		}else if(!pet){
			response.status(404).end()
		}else{
			response.status(200).json(pet)
		}
	})
	
})

app.post("/pets", function(request, response){
	
	const name = request.body.name
	
	petHandler.createPet(name, function(errors, id){
		if(errors.includes("databaseError")){
			response.status(500).end()
		}else if(0 < errors.length){
			response.status(400).json(errors)
		}else{
			response.setHeader("Location", "/pets/"+id)
			response.status(201).end()
		}
	})
	
})

app.put("/pets/:id", function(request, response){
	
	const id = request.params.id
	const name = request.body.name
	
	petHandler.updatePetById(name, id, function(errors, petExists){
		if(errors.includes("databaseError")){
			response.status(500).end()
		}else if(0 < errors.length){
			response.status(400).json(errors)
		}else if(!petExists){
			response.status(404).end()
		}else{
			response.status(204).end()
		}
	})
	
})

app.delete("/pets/:id", function(request, response){
	
	const id = request.params.id
	
	petHandler.deletePetById(id, function(errors, petDidExist){
		if(0 < errors.length){
			response.status(500).end()
		}else if(!petDidExist){
			response.status(404).end()
		}else{
			response.status(204).end()
		}
	})
	
})

const correctUsername = "peter"
const correctPassword = "abc123"
const serverSecret = "sdfkjdslkfjslkfd"

app.post("/tokens", function(request, response){
	
	const grantType = request.body.grant_type
	const username = request.body.username
	const password = request.body.password
	
	if(grantType != "password"){
		response.status(400).json({error: "unsupported_grant_type"})
		return
	}
	
	// TODO: Handle other type of errors as described at:
	// https://tools.ietf.org/html/rfc6749#section-5.2
	
	if(username == correctUsername && password == correctPassword){
		
		// TODO: Put user authorization info in the access token.
		const payload = {id: 123}
		// TODO: Better to use jwt.sign asynchronously.
		const accessToken = jwt.sign(payload, serverSecret)
		
		// TODO: Put user info in the id token.
		// Try to use the standard claims:
		// https://openid.net/specs/openid-connect-core-1_0.html#StandardClaims
		const idToken = jwt.sign(
			{sub: 123, email: "123@gmail.com"},
			"lkjlkjlkjljlk"
		)
		
		response.status(200).json({
			access_token: accessToken,
			id_token: idToken
		})
		
	}else{
		response.status(400).json({error: "invalid_grant"})
	}
	
})

app.listen(8080)