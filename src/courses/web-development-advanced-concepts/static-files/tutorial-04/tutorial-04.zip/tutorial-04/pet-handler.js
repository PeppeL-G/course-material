const db = require('./db')

function getValidationErrors(name){
	
	const errors = []
	
	if(name.length < 3){
		errors.push("nameTooShort")
	}
	
	return errors
	
}

exports.getAllPets = function(callback){
	
	const query = `SELECT * FROM pets`
	const values = []
	
	db.all(query, values, function(error, pets){
		if(error){
			callback(["databaseError"])
		}else{
			callback([], pets)
		}
	})
	
}

exports.getPetById = function(id, callback){
	
	const query = `SELECT * FROM pets WHERE id = ?`
	const values = [id]
	
	db.get(query, values, function(error, pet){
		if(error){
			callback(["databaseError"])
		}else{
			callback([], pet)
		}
	})
	
}

exports.createPet = function(name, callback){
	
	const errors = getValidationErrors(name)
	
	if(0 < errors.length){
		callback(errors)
		return
	}
	
	const query = `INSERT INTO pets (name) VALUES (?)`
	const values = [name]
	
	db.run(query, values, function(error){
		if(error){
			callback(["databaseError"])
		}else{
			callback([], this.lastID)
		}
	})
	
}

exports.updatePetById = function(name, id, callback){
	
	const errors = getValidationErrors(name)
	
	if(0 < errors.length){
		callback(errors)
		return
	}
	
	const query = `UPDATE pets SET name = ? WHERE id = ?`
	const values = [name, id]
	
	db.run(query, values, function(error){
		if(error){
			callback(["databaseError"])
		}else{
			callback([], 0 < this.changes)
		}
	})
	
}

exports.deletePetById = function(id, callback){
	
	const query = `DELETE FROM pets WHERE id = ?`
	const values = [id]
	
	db.run(query, values, function(error){
		if(error){
			callback(["databaseError"])
		}else{
			callback([], 0 < this.changes)
		}
	})
	
}