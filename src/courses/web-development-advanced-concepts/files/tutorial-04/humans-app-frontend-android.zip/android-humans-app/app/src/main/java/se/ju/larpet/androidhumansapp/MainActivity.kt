package se.ju.larpet.androidhumansapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import se.ju.larpet.androidhumansapp.databinding.ActivityMainBinding
import se.ju.larpet.androidhumansapp.databinding.ItemViewHumanBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    val viewModel: MainActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater).apply {
            setContentView(root)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)

        viewModel.humans.observe(this){
            binding.recyclerView.adapter = HumansAdapter(it)
        }

        binding.fab.setOnClickListener{
            startActivity(
                Intent(this, CreateHumanActivity::class.java)
            )
        }

    }

    override fun onRestart() {
        super.onRestart()

        viewModel.loadAllHumans()

    }

}

class HumanViewHolder(
    val binding: ItemViewHumanBinding
    ) : RecyclerView.ViewHolder(binding.root)

class HumansAdapter(val humans: List<Human>) : RecyclerView.Adapter<HumanViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = HumanViewHolder(
            ItemViewHumanBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
    )

    override fun onBindViewHolder(holder: HumanViewHolder, position: Int) {

        val human = humans[position]

        holder.binding.textView.text = "#${human.id} ${human.name}"
        holder.binding.textView.setOnClickListener {
            holder.binding.textView.context.startActivity(
                Intent(
                    holder.binding.textView.context,
                    ViewHumanActivity::class.java
                ).apply{
                    putExtra(ViewHumanActivity.EXTRA_HUMAN_ID, human.id)
                }
            )
        }

    }

    override fun getItemCount() = humans.size

}

class MainActivityViewModel : ViewModel(){

    val humans = MutableLiveData<List<Human>>()

    init {
        loadAllHumans()
    }

    fun loadAllHumans(){

        viewModelScope.launch(Dispatchers.IO) {

            try {

                humans.postValue(
                    humansAppClient.getAllHumans()
                )

            }catch (exception: HttpException){
                // TODO: Display network error message.
            }

        }

    }

}