package se.ju.larpet.androidhumansapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.HttpException
import se.ju.larpet.androidhumansapp.databinding.ActivityCreateHumanBinding

class CreateHumanActivity : AppCompatActivity() {

    lateinit var binding: ActivityCreateHumanBinding
    val viewModel: CreateHumanActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCreateHumanBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.createButton.setOnClickListener {

            val human = Human(
                -1,
                binding.nameEditText.text.toString(),
                binding.ageEditText.text.toString().run{
                    if (isEmpty()) 0 else toInt()
                }
            )

            viewModel.createHuman(human)

        }

        viewModel.createdHumanId.observe(this){
            finish()
            startActivity(
                Intent(this, ViewHumanActivity::class.java).apply{
                    putExtra(ViewHumanActivity.EXTRA_HUMAN_ID, it)
                }
            )
        }

        viewModel.createErrors.observe(this){
            supportFragmentManager.beginTransaction()
                .replace(
                    R.id.frame_layout,
                    ShowErrorsFragment.newInstance(
                        "Could not create human because:",
                        ArrayList(it)
                    )
                )
                .commit()
        }

    }

}

class CreateHumanActivityViewModel: ViewModel(){

    val createdHumanId = MutableLiveData<Int>()
    val createErrors = MutableLiveData<List<String>>()

    fun createHuman(human: Human){

        viewModelScope.launch(Dispatchers.IO) {

            try {

                val createdHuman = humansAppClient.createHuman(human)
                createdHumanId.postValue(createdHuman.id)

            }catch(exception: HttpException){

                if(exception.code() == 400) {

                    val type = object : TypeToken<List<String>>() {}.type
                    val errorMessages = Gson().fromJson<List<String>>(
                        exception.response()?.errorBody()?.charStream(),
                        type
                    )
                    createErrors.postValue(errorMessages)

                }else{

                    createErrors.postValue(listOf("Server error."))

                }
            }

        }

    }

}