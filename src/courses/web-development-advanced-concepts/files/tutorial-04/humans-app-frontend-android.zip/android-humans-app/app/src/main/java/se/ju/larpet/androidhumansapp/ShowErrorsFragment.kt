package se.ju.larpet.androidhumansapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import se.ju.larpet.androidhumansapp.databinding.FragmentShowErrorsBinding
import se.ju.larpet.androidhumansapp.databinding.ItemViewErrorBinding

const val ARG_ERROR_MESSAGE = "ARG_ERROR_MESSAGE"
const val ARG_ERROR_MESSAGES = "ARG_ERROR_MESSAGES"

class ShowErrorsFragment : Fragment() {

    lateinit var binding: FragmentShowErrorsBinding

    lateinit var errorMessage: String
    lateinit var errorMessages: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requireArguments().run {
            errorMessage = getString(ARG_ERROR_MESSAGE)!!
            errorMessages = getStringArrayList(ARG_ERROR_MESSAGES)!!
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentShowErrorsBinding.inflate(
        inflater,
        container,
        false
    ).run{
        binding = this
        root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.errorMessageTextView.text = errorMessage
        binding.recyclerView.run{
            layoutManager = LinearLayoutManager(requireContext())
            adapter = ErrorsAdapter(errorMessages)
        }

    }

    companion object {
        fun newInstance(errorMessage: String, errorMessages: ArrayList<String>) =
            ShowErrorsFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_ERROR_MESSAGE, errorMessage)
                    putStringArrayList(ARG_ERROR_MESSAGES, errorMessages)
                }
            }
    }

}

class ErrorViewHolder(
    val binding: ItemViewErrorBinding
    ) : RecyclerView.ViewHolder(binding.root)

class ErrorsAdapter(val errorMessages: List<String>) : RecyclerView.Adapter<ErrorViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ErrorViewHolder(
        ItemViewErrorBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
    )

    override fun onBindViewHolder(holder: ErrorViewHolder, position: Int) {

        val errorMessage = errorMessages[position]

        holder.binding.textView.text = " - $errorMessage"

    }

    override fun getItemCount() = errorMessages.size

}