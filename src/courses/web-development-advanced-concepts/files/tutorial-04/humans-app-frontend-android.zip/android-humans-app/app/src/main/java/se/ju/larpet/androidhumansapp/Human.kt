package se.ju.larpet.androidhumansapp

data class Human(
    val id: Int,
    val name: String,
    val age: Int
)