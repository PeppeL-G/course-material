package se.ju.larpet.androidhumansapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface HumansAppClient {

    @GET("humans")
    suspend fun getAllHumans(): List<Human>

    @GET("humans/{id}")
    suspend fun getHumanById(
        @Path("id") id: Int
    ): Human

    @POST("/humans")
    suspend fun createHuman(@Body human: Human): Human

}

val humansAppClient = Retrofit
    .Builder()
    .baseUrl("http://10.0.2.2:3000/") // In Android emulators, this is the IP address to the host machine (the computer the emulator runs on).
    .addConverterFactory(GsonConverterFactory.create())
    .build()
    .create(HumansAppClient::class.java)
