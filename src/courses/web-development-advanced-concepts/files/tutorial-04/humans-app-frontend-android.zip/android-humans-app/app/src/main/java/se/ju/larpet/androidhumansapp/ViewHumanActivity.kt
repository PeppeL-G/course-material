package se.ju.larpet.androidhumansapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.HttpException
import se.ju.larpet.androidhumansapp.databinding.ActivityViewHumanBinding

class ViewHumanActivity : AppCompatActivity() {

    companion object{
        const val EXTRA_HUMAN_ID = "EXTRA_HUMAN_ID"
    }

    lateinit var binding: ActivityViewHumanBinding
    val viewModel: ViewHumanActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityViewHumanBinding.inflate(layoutInflater).apply{
            setContentView(root)
        }

        if(savedInstanceState == null){
            viewModel.humanId = intent.getIntExtra(EXTRA_HUMAN_ID, -1)
            viewModel.loadHuman()
        }

        viewModel.human.observe(this){
            binding.idTextView.text = "Id: ${it.id}"
            binding.nameTextView.text = "Name: ${it.name}"
            binding.ageTextView.text = "Age: ${it.age}"
        }

    }

}

class ViewHumanActivityViewModel : ViewModel(){

    var humanId = -1
    val human = MutableLiveData<Human>()

    fun loadHuman(){

        viewModelScope.launch(Dispatchers.IO) {

            try {

                human.postValue(
                    humansAppClient.getHumanById(humanId)
                )

            }catch(exception: HttpException){

                if (exception.response()?.code() == 404){
                    // TODO: Display not found error message.
                }else{
                    // TODO: Display network error message.
                }

            }

        }

    }

}