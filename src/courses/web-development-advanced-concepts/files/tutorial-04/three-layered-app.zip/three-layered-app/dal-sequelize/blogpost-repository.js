const { Sequelize, DataTypes } = require('sequelize')

const sequelize = new Sequelize('sqlite::memory')

const blogpost = sequelize.define('blogpost', {
	title: DataTypes.TEXT,
	description: DataTypes.TEXT
})

blogpost.sync()

module.exports = function createBlogpostRepository(){
	
	return {
		async getAll(){
			// TODO: Don't expose internal errors.
			await blogpost.create({
				title: "The first blogpost",
				description: "Hello",
			})
			return (await blogpost.findAll()).map(
				b => b.dataValues
			)
		}
	}
	
}