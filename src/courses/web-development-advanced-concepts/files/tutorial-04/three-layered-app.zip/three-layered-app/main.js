const awilix = require('awilix')

const container = awilix.createContainer()

container.register(
	'blogpostRepository',
	awilix.asFunction(require('./dal-sequelize/blogpost-repository.js'))
)
container.register(
	'blogpostManager',
	awilix.asFunction(require('./bll/blogpost-manager.js'))
)
container.register(
	'app',
	awilix.asFunction(require('./pl/app.js'))
)

const app = container.resolve('app')

setTimeout(function(){
	app.start()
}, 1000)