module.exports = function createBlogpostManager({blogpostRepository}){
	
	return {
		
		async getAll(){
			return await blogpostRepository.getAll()
		},
		
	}
	
}