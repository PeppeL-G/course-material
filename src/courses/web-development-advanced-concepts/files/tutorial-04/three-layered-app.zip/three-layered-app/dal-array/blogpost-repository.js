const blogposts = [{
	id: 1,
	title: "First blogpost",
	content: "This is the first blogpost."
}, {
	id: 2,
	title: "Second blogpost",
	content: "This is the second blogpost."
}]

module.exports = function createBlogpostRepository(){
	
	return {
		async getAll(){
			return await new Promise(function(resolve, reject){
				setTimeout(function(){
					resolve(blogposts)
				}, 1000)
			})
		}
	}
	
}