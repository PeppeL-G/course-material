module.exports = function createApp({blogpostManager}){
	
	return {
		
		async start(){
			
			try{
				const allBlogposts = await blogpostManager.getAll()
				console.log(allBlogposts)
			}catch(errors){
				console.log(errors)
			}
			
		}
		
	}
	
}