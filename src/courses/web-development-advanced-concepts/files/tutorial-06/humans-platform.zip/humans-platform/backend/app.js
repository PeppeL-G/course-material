const express = require('express')
const jwt = require('jsonwebtoken')

const humans = [{
	id: 1,
	name: "Alice",
	age: 10
}, {
	id: 2,
	name: "Bob",
	age: 15
}]

function getValidationErrors(name, age){
	
	const validationErrors = []
	
	if(name.length < 3){
		validationErrors.push("Name must be at least 3 characters.")
	}
	
	if(age < 0){
		validationErrors.push("Age can't be negative.")
	}
	
	return validationErrors
	
}

const app = express()

app.use(express.json())
app.use(express.urlencoded({
	extended: false,
}))

// Add CORS, so client-side code on other websites are allowed
// to send HTTP requests to us.
app.use(function(request, response, next){
	response.setHeader("Access-Control-Allow-Origin", "*")
	response.setHeader("Access-Control-Allow-Methods", "*")
	response.setHeader("Access-Control-Allow-Headers", "*")
	response.setHeader("Access-Control-Expose-Headers", "*")
	next()
})

/*
// A Middleware checking if the user is logged in or not
// (if the user provided a valid Access Token or not)
app.use(function(request, response, next){
	
	// TODO: This will crash if Authorization header is missing or malformed.
	const authorizationHeader = request.header("Authorization") // "Bearer XXX"
	const accessToken = authorizationHeader.substring("Bearer ".length) // "XXX"
	
	jwt.verify(accessToken, "sdfsdfsdfsdfsdfsdf", function(error, payload){
		
		if(!error){
			request.isLoggedIn = true
		}
		
		next()
		
	})
	
})
*/

app.get("/humans", function(request, response){
	
	response.status(200).json(humans)
	
})

app.get("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const human = humans.find(h => h.id == id)
	
	if(human){
		response.status(200).json(human)
	}else{
		response.status(404).end()
	}
	
})

app.post("/humans", function(request, response){
	
	const name = request.body.name
	const age = request.body.age
	
	/*
	if(!request.isLoggedIn){
		response.status(401).end()
		return
	}
	*/
	
	const errors = getValidationErrors(name, age)
	
	if(errors.length == 0){
		
		const id = humans[humans.length-1].id + 1
		
		const human = {
			id,
			name,
			age
		}
		
		humans.push(human)
		
		response.setHeader("Location", "/humans/"+id)
		response.status(201).json(human)
		
	}else{
		
		response.status(400).json(errors)
		
	}
	
})

app.post("/tokens", function(request, response){
	
	// TODO: Verify grant_type is password.
	const grantType = request.body.grant_type
	const username = request.body.username
	const password = request.body.password
	
	if(username == "Alice" && password == "abc123"){
		
		// You probably want to put the user's id in the payload, so
		// you remember which account the user logged in to.
		const payload = {
			isLoggedIn: true
		}
		
		// TODO: Secret better put in constant.
		jwt.sign(payload, 'sdfsdfsdfsdfsdfsdf', function(err, token) {
			
			// TODO: Send back id token too per the Open ID Connect specification.
			response.status(200).json({
				"access_token": token
			})
			
		})
		
	}else{
		
		// TODO: Check OAuth 2.0 spec on what error to send back when.
		response.status(400).json({error: "something"})
		
	}
	
})

app.delete("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	// TODO: Add authorization.
	
	const index = humans.findIndex(h => h.id == id)
	
	if(index == -1){
		response.status(404).end()
	}else{
		humans.splice(index, 1)
		response.status(204).end()
	}
	
})

app.put("/humans/:id", function(request, response){
	
	const id = request.params.id
	
	const newName = request.body.name
	const newAge = request.body.age
	
	// TODO: Add authorization.
	
	const human = humans.find(h => h.id == id)
	
	if(!human){
		response.status(404).end()
	}else{
		
		const errors = getValidationErrors(newName, newAge)
		
		if(errors.length == 0){
			
			human.name = newName
			human.age = newAge
			
			response.status(204).end()
			
		}else{
			
			response.status(400).json(errors)
			
		}
		
	}
	
})

app.listen(3000)