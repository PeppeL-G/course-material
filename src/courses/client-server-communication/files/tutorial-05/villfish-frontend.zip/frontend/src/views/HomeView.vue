<script>
export default {
	
}
</script>

<template>
	<div class="page">
		<h1>Home</h1>
		<p>This is the home page!</p>
	</div>
</template>

<style scoped>

.page{
	background-color: lime;
}

</style>
