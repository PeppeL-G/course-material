<script>
export default {
	data(){
		return {
			type: "",
			weight: 0,
			accountId: 0,
			adHasBeenCreated: false,
			errors: []
		}
	},
	methods: {
		createAd(){
			
			const ad = {
				type: this.type,
				weight: this.weight,
				accountId: this.accountId
			}
			
			fetch("http://localhost:8080/ads", {
				method: "POST",
				headers: new Headers({
					"Content-Type": "application/json"
				}),
				body: JSON.stringify(ad)
			}).then(response => {
				
				if(response.status == 201){
					this.adHasBeenCreated = true
				}else if(response.status == 400){
					
					response.json().then(errors => {
						this.errors = errors
					})
					
				}else if(response.status == 500){
					this.errors.push("Server is not working as it should")
				}
				
			})
			
		}
	}
}
</script>

<template>
	<div class="page">
		<h1>Create ad</h1>
		
		<div v-if="adHasBeenCreated">
			<p>The ad has been created.</p>
		</div>
		
		<div v-else>
			
			<div>
				Type: <input type="text" v-model="type">
			</div>
			<div>
				Weight: <input type="number" v-model="weight">
			</div>
			<div>
				Account Id: <input type="number" v-model="accountId">
			</div>
			<button @click="createAd">Create ad</button>
			
			<div v-if="0 < errors.length">
				<p>Couldn't create the ad, because:</p>
				<ul>
					<li v-for="error in errors">
						{{error}}
					</li>
				</ul>
			</div>
			
		</div>
		
	</div>
</template>

<style scoped>

.page{
	background-color: lime;
}

</style>
