<script>
	
</script>


<template>
	<div>
		<h1>Start</h1>
		<p>This is the start page</p>
	</div>
</template>

<style scoped>
	
</style>