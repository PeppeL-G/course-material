<template>
	<div>
		<h1>Contact</h1>
		<p>This is the contact page</p>
	</div>
</template>

<style scoped>
	
</style>