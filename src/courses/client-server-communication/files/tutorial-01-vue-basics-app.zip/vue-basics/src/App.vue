<script>

import Start from './Start.vue'
import Contact from './Contact.vue'
import About from './About.vue'

export default {
	
	components: {
		Start,
		Contact,
		About
	},
	
	// Create and return the model.
	data(){
		return {
			currentPage: "start"
		}
	},
	
	// The controller functions.
	methods: {
		changeToStartPage(){
			this.currentPage = "start"
		},
		changeToAboutPage(){
			this.currentPage = "about"
		},
		changeToContactPage(){
			this.currentPage = "contact"
		}
	}
	
}

</script>

<template>
	
	<header>
		My App
	</header>
	
	<nav>
		<button @click="changeToStartPage">Start</button>
		<button @click="changeToAboutPage">About</button>
		<button @click="changeToContactPage">Contact</button>
	</nav>
	
	<main>
		
		<Start v-if="currentPage == 'start'" />
		<About v-if="currentPage == 'about'" />
		<Contact v-if="currentPage == 'contact'" />
		
	</main>
	
</template>

<style scoped>
	
	header{
		text-align: center;
		font-size: 3em;
	}
	
	nav{
		display: flex;
	}
	
	nav > *{
		flex: 1;
	}
	
</style>