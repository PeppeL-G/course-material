const express = require('express')
const sqlite3 = require('sqlite3')

const db = new sqlite3.Database('villfish.db')

db.run(`CREATE TABLE IF NOT EXISTS ads (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	type TEXT,
	weight INTEGER
)`)

// Create the app object we can use to tell express
// how to handle incoming HTTP requests.
const app = express()

app.use(function(request, response, next){
	response.setHeader("Access-Control-Allow-Origin", "*")
	response.setHeader("Access-Control-Allow-Method", "*")
	response.setHeader("Access-Control-Allow-Headers", "*")
	response.setHeader("Access-Control-Expose-Headers", "*")
	next()
})

app.use(
	express.json()
)

// GET /ads
app.get("/ads", function(request, response){
	
	const query = "SELECT * FROM ads"
	
	db.all(query, function(error, ads){
		
		if(error){
			console.log(error)
			response.status(500).end()
		}else{
			response.status(200).json(ads)
		}
		
	})
	
})

// GET /ads/57
app.get("/ads/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "SELECT * FROM ads WHERE id = ?"
	const values = [id]
	
	db.get(query, values, function(error, ad){
		
		if(error){
			response.status(500).end()
		}else if(ad){
			response.status(200).json(ad)
		}else{
			response.status(404).end()
		}
		
	})
	
})

// POST /ads
// Content-Type: application/json
// {"type": "bike", "weight": 4}
app.post('/ads', function(request, response){
	
	const type = request.body.type
	const weight = request.body.weight
	
	const errorCodes = []
	
	if(type != "shark" && type != "abborre"){
		errorCodes.push("invalidType")
	}
	
	if(weight < 0){
		errorCodes.push("invalidWeight")
	}
	
	if(0 < errorCodes.length){
		response.status(400).json(errorCodes)
	}else{
		
		const query = "INSERT INTO ads (type, weight) VALUES (?, ?)"
		const values = [type, weight]
		
		db.run(query, values, function(error){
			if(error){
				response.status(500).end()
			}else{
				response.status(201).end()
			}
		})
		
	}
	
})

// Tell express to start listening for incoming
// HTTP requests on port 8080.
// (http://localhost:8080)
app.listen(8080)