<script>
import Footer from './components/Footer.vue'

export default {
	components: {
		Footer,
	},
}

</script>

<template>
	
	<header>
		My app!
	</header>
	
	<nav>
		<RouterLink to="/">Start</RouterLink>
		<RouterLink to="/ads">Ads</RouterLink>
		<RouterLink to="/create-add">Create</RouterLink>
	</nav>
	
	<main>
		<RouterView></RouterView>
	</main>
	
	<Footer :copyrightYear="2022"></Footer>
	
</template>

<style scoped>

nav{
	background-color: yellow;
}

</style>
