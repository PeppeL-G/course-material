<script>
	export default {
		data(){
			return {
				ads: []
			}
		},
		mounted(){
			fetch("http://localhost:8080/ads").then((response) => {
				return response.json()
			}).then(ads => {
				this.ads = ads
			})
		},
	}
</script>

<template>
	<div class="page">
		<h1>Ads</h1>
		<p>Here are all the ads!</p>
		<ul>
			<li v-for="ad in ads">
				{{ad.type}} {{ad.weight}}
			</li>
		</ul>
	</div>
</template>
