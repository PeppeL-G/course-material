const express = require('express')

// Our data.
const adds = [{
	id: 1,
	type: "shark",
	weight: 50,
}, {
	id: 2,
	type: "abborre",
	weight: 3
}]

// Create the app object we can use to tell express
// how to handle incoming HTTP requests.
const app = express()

// GET /adds
app.get("/adds", function(request, response){
	response.status(200).json(adds)
})

// GET /adds/57
app.get("/adds/:id", function(request, response){
	
	const id = request.params.id
	
	// Find the add with the provided id.
	const add = adds.find(a => a.id == id)
	
	if(add){
		response.status(200).json(add)
	}else{
		response.status(404).end()
	}
	
})

// Tell express to start listening for incoming
// HTTP requests on port 8080.
// (http://localhost:8080)
app.listen(8080)