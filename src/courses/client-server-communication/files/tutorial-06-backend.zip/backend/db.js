const sqlite3 = require('sqlite3')

const db = new sqlite3.Database("my-database.db")

db.run("PRAGMA foreign_keys = ON")

db.run(`
	CREATE TABLE IF NOT EXISTS accounts (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		username TEXT,
		password TEXT,
		CONSTRAINT unique_username UNIQUE(username)
	)
`)

db.run(`
	CREATE TABLE IF NOT EXISTS tweets (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		accountId INTEGER,
		message TEXT,
		createdAt INTEGER,
		FOREIGN KEY (accountId) REFERENCES accounts(id) ON DELETE CASCADE
	)
`)

exports.getAllTweets = function(callback){
	
	const query = "SELECT * FROM tweets"
	
	db.all(query, function(error, tweets){
		
		callback(error, tweets)
		
	})
	
}

exports.getTweetById = function(id, callback){
	
	const query = "SELECT * FROM tweets WHERE id = ?"
	const values = [id]
	
	db.get(query, values, function(error, tweet){
		callback(error, tweet)
	})
	
}

exports.deleteTweetById = function(id, callback){
	
	const query = "DELETE FROM tweets WHERE id = ?"
	const values = [id]
	
	db.run(query, values, function(error){
		callback(error)
	})
	
}

exports.createTweet = function(accountId, message, createdAt, callback){
	
	const query = "INSERT INTO tweets (accountId, message, createdAt) VALUES (?, ?, ?)"
	const values = [accountId, message, createdAt]
	
	db.run(query, values, function(error){
		callback(error, this.lastID)
	})
	
}

exports.updateTweetById = function(id, updatedAccountId, updatedMessage, updateCreatedAt, callback){
	
	const query = `
	UPDATE tweets SET
		accountId = ?,
		message = ?,
		createdAt = ?
	WHERE
		id = ?
	`
	const values = [updatedAccountId, updatedMessage, updateCreatedAt, id]

	db.run(query, values, function(error){
		callback(error)
	})
	
}

exports.createAccount = function(username, password, callback){
	const query = "INSERT INTO accounts (username, password) VALUES (?, ?)"
	const values = [username, password]
	
	db.run(query, values, function(error){
		callback(error, this.lastID)
	})
}

exports.getAccountByUsername = function(username, callback){
	
	const query = "SELECT * FROM accounts WHERE username = ?"
	const values = [username]
	
	db.get(query, values, function(error, account){
		callback(error, account)
	})
}