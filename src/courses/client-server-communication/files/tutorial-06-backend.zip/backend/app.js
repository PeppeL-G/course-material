const express = require('express')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')
const settings = require('./settings')
const db = require('./db')
const accountRouter = require('./accountRouter')
const tweetRouter = require('./tweetRouter')

const app = express()

app.use(function(request, response, next){
	
	response.setHeader("Access-Control-Allow-Origin", "*")
	response.setHeader("Access-Control-Allow-Methods", "*")
	response.setHeader("Access-Control-Allow-Headers", "*")
	response.setHeader("Access-Control-Expose-Headers", "*")
	
	next()
	
})

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
	extended: false
}))

app.use("/accounts", accountRouter)
app.use("/tweets", tweetRouter)


// Implemented per OAuth 2.0 (Resource Owner Password Credentials Grant):
// https://tools.ietf.org/html/rfc6749
// OpenID Connect also implemented (ID token).
// POST /accounts
// Content-Type: application/x-www-form-urlencoded
// Body: grant_type=password&username=Alice&password=abc123
app.post("/tokens", function(request, response){
	
	const grant_type = request.body.grant_type
	const username = request.body.username
	const password = request.body.password
	
	db.getAccountByUsername(username, function(error, account){
		if(error){
			response.status(500).end()
		}else if(!account || account.password != password){
			response.status(400).json({error: "invalid_client"})
		}else{
			
			const accessToken = jwt.sign({
				accountId: account.id
			}, settings.accessTokenSecret)
			
			const idToken = jwt.sign({
				sub: account.id,
				preferred_username: account.username
			}, "some secret that doesn't matter")
			
			response.status(200).json({
				access_token: accessToken,
				id_token: idToken
			})
			
		}
	})
	
})

app.listen(3000)