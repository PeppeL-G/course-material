const express = require('express')
const db = require('./db')

const router = express.Router()

// POST /accounts
// Content-Type: application/json
// Body: {"username": "Alice", "password": "abc123"}
router.post("/", function(request, response){
	
	if(
		typeof request.body.username != "string" ||
		typeof request.body.password != "string"
	){
		response.status(422).end()
		return
	}
	
	const username = request.body.username
	const password = request.body.password
	
	// TODO: Validate account details.
	
	// TODO: Hash password.
	
	db.createAccount(username, password, function(error, id){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: UNIQUE constraint failed: accounts.username"){
				response.status(400).json(["usernameTaken"])
			}else{
				response.status(500).end()
			}
		}else{
			
			response.setHeader("Location", "/accounts/"+id)
			response.status(201).end()
		}
	})
	
})

module.exports = router