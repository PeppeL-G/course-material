const express = require('express')
const db = require('./db')
const settings = require('./settings')
const jwt = require('jsonwebtoken')

const router = express.Router()

// GET /tweets
router.get("/", function(request, response){
	
	db.getAllTweets(function(error, tweets){
		
		if(error){
			response.status(500).end()
		}else{
			response.status(200).json(tweets)
		}
		
	})
	
})

// GET /tweets/23
router.get("/:id", function(request, response){
	
	const id = request.params.id
	
	db.getTweetById(id, function(error, tweet){
		if(error){
			response.status(500).end()
		}else if(tweet){
			response.status(200).json(tweet)
		}else{
			response.status(404).end()
		}
	})
	
})

// DELETE /tweets/23
router.delete("/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "DELETE FROM tweets WHERE id = ?"
	const values = [id]
	
	db.run(query, values, function(error){
		if(error){
			response.status(500).end()
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

// POST /tweets
// Content-Type: application/json
// Authorization: Bearer THE_ACCESS_TOKEN
// Body: {"accountId": 123, "message": "Hello", "createdAt": 123123}
router.post("/", function(request, response){
	
	let payload = null
	
	try{
		
		const authorizationHeader = request.get("Authorization") // "Bearer THE_ACCESS_TOKEN"
		const accessToken = authorizationHeader.substr("Bearer ".length) // "THE_ACCESS_TOKEN"
		
		payload = jwt.verify(accessToken, settings.accessTokenSecret)
		
	}catch(e){
		// No access token provided or the access token was invalid.
	}
	
	const accountId = request.body.accountId
	const message = request.body.message
	const createdAt = request.body.createdAt
	
	// Authorization.
	if(payload == null || payload.accountId != accountId){
		response.status(401).end()
		return
	}
	
	// Validation
	const errors = []
	
	if(message.length < 3){
		errors.push("messageTooShort")
	}else if(250 < message.length){
		errors.push("messageTooLong")
	}
	
	if(0 < errors.length){
		response.status(400).json(errors)
		return
	}
	
	// Creation.
	db.createTweet(accountId, message, createdAt, function(error, id){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: FOREIGN KEY constraint failed"){
				response.status(400).json(["accountDoesNotExist"])
			}else{
				response.status(500).end()
			}
		}else{
			
			response.setHeader("Location", "/tweets/"+id)
			response.status(201).end()
			
		}
	})
	
})

// PUT /tweets23
// Content-Type: application/json
// Body: {"id": 23, "accountId": 123, "message": "Hi", "createdAt": 321321}
router.put("/:id", function(request, response){
	
	const id = request.params.id
	const updatedAccountId = request.body.accountId
	const updatedMessage = request.body.message
	const updateCreatedAt = request.body.createdAt
	
	// TODO: Add validation the same way as in POST /tweets
	// (or whichever validation rules you want to have).
	
	// TODO: Add authorization the same way as in POST /tweets.
	
	db.updateTweetById(id, updatedAccountId, updatedMessage, updateCreatedAt, function(error){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: FOREIGN KEY constraint failed"){
				response.status(400).json(["accountDoesNotExist"])
			}else{
				response.status(500).end()
			}
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

module.exports = router