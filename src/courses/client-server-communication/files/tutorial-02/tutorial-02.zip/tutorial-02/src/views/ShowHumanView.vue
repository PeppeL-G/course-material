<script>

import ShowErrorMessages from '../components/ShowErrorMessages.vue';
import { getHumanById } from '../sdk.js';

export default {
	data(){
		return {
			human: {
				id: 0,
				name: "",
				age: 0
			},
			currentState: 'loading',
			errorMessages: [],
		}
	},
	mounted(){
		
		getHumanById(this.$route.params.id, (errorMessages, human) => {
			
			if(0 < errorMessages.length){
				this.currentState = 'failedToLoadHuman'
				this.errorMessages = errorMessages
			}else{
				this.currentState = 'succeededToLoadHuman'
				this.human = human
			}
			
		})
		
	},
	components: {
		ShowErrorMessages,
	}
}

</script>

<template>
	<h1>Show Human!</h1>
	
	<div v-if="currentState == 'loading'">
		Loading...
	</div>
	
	<div v-else-if="currentState == 'succeededToLoadHuman'">
		<p>{{human.name}} is {{human.age}} years old.</p>
	</div>
	
	<div v-else-if="currentState == 'failedToLoadHuman'">
		Failed to load because:
		<ShowErrorMessages :errorMessages="errorMessages" />
	</div>
	
</template>