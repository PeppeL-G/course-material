import { createRouter, createWebHistory } from 'vue-router'
import AllHumansView from './views/AllHumansView.vue'
import CreateHumanView from './views/CreateHumanView.vue'
import ShowHumanView from './views/ShowHumanView.vue'

const router = createRouter({
	history: createWebHistory(),
	routes: [
		{path: "/", component: AllHumansView},
		{path: "/create-human", component: CreateHumanView},
		{path: "/show-human/:id", component: ShowHumanView}
	],
})

export default router
