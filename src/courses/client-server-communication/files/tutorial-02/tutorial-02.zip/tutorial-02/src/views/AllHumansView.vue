<script>
import { getAllHumans } from '../sdk.js'
import ShowErrorMessages from '../components/ShowErrorMessages.vue'

export default {
	data() {
		return {
			currentState: "loading",
			loadedHumans: [],
			errorMessages: [],
		};
	},
	mounted() {
		getAllHumans((errorMessages, humans) => {
			if (0 < errorMessages.length) {
				this.currentState = "failedToLoadHumans";
				this.errorMessages = errorMessages;
			}
			else {
				this.loadedHumans = humans;
				this.currentState = "succeededToLoad";
			}
		});
	},
	components: { ShowErrorMessages }
}

</script>

<template>
	
	<h1>All humans!</h1>
	
	<div v-if="currentState == 'loading'">
		Loading...
	</div>
	
	<div v-else-if="currentState == 'succeededToLoad'">
		Here are the humans:
		<ul>
			<li v-for="human in loadedHumans">
				<RouterLink :to="`/show-human/${human.id}`">
					{{human.name}}
				</RouterLink>
			</li>
		</ul>
	</div>
	
	<div v-else-if="currentState == 'failedToLoadHumans'">
		Couldn't load humans:
		<ShowErrorMessages :errorMessages="errorMessages" />
	</div>
	
</template>