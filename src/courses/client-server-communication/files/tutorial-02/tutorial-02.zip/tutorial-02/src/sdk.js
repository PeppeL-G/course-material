const humans = [{
	id: 1,
	name: "Alice",
	age: 15,
}, {
	id: 2,
	name: "Bob",
	age: 20,
}, {
	id: 3,
	name: "Claire",
	age: 25,
}]

const simulatedDelayInMs = 1000

// callback = (errorMessages, humans) => ...
export function getAllHumans(callback){
	
	setTimeout(function(){
		
		callback([], humans)
		
	}, simulatedDelayInMs)
	
}

// human = {name: "David", age: 30}
// callback = (errorMessages, humanId) => ...
export function createHuman(human, callback){
	
	setTimeout(function(){
		
		const errorMessages = []
		
		if(human.name.length < 2){
			errorMessages.push("Name is too short")
		}
		if(human.age < 0){
			errorMessages.push("Age can't be negative")
		}
		
		if(0 < errorMessages.length){
			
			callback(errorMessages, null)
			
		}else{
			
			human.id = humans.at(-1).id + 1
			humans.push(human)
			callback([], human.id)
			
		}
		
	}, simulatedDelayInMs)
	
}

// humanId = 2
// callback = (errorMessages, human)
export function getHumanById(humanId, callback){
	
	setTimeout(function(){
		
		const human = humans.find(h => h.id == humanId)
		
		if(!human){
			callback(["No human with that id"], null)
		}else{
			callback([], human)
		}
		
	}, simulatedDelayInMs)
	
}