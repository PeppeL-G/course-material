<script>

export default {
	props: ["errorMessages"]
}

</script>

<template>
	<ul>
		<li v-for="errorMessage in errorMessages">
			{{errorMessage}}
		</li>
	</ul>
</template>

<style scoped>
	
	li{
		color: red;
	}
	
</style>