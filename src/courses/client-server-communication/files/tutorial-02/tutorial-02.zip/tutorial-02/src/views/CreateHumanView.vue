<script>

import { createHuman } from '../sdk.js'
import ShowErrorMessages from '../components/ShowErrorMessages.vue'

export default {
	data(){
		return {
			human: {
				name: "",
				age: 0,
			},
			currentState: '',
			errorMessages: [],
		}
	},
	methods: {
		saveHuman(){
			
			this.currentState = 'loading'
			
			createHuman(this.human, (errorMessages, humanId) => {
				
				if(0 < errorMessages.length){
					this.currentState = 'failedToStoreHuman'
					this.errorMessages = errorMessages
				}else{
					this.currentState = 'succeededToStoreHuman'
				}
				
			})
			
		}
	},
	components: {
		ShowErrorMessages,
	}
}

</script>

<template>
	<h1>Create Human!</h1>
	
	<form @submit.prevent="saveHuman">
		
		<div>
			Name: <input v-model="human.name" type="text">
		</div>
		
		<div>
			Age: <input v-model="human.age" type="number">
		</div>
		
		<input type="submit" value="Create">
		
	</form>
	
	<div v-if="currentState == 'loading'">
		Loading...
	</div>
	<div v-else-if="currentState == 'succeededToStoreHuman'">
		Created!
	</div>
	<div v-if="currentState == 'failedToStoreHuman'">
		Got errors!
		<ShowErrorMessages :errorMessages="errorMessages" />
	</div>
	
</template>