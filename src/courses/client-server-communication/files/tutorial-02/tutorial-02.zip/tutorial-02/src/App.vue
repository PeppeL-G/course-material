<script>

export default {
}

</script>

<template>
	
	<header>
		Humans
	</header>
	
	<nav>
		<RouterLink to="/">All</RouterLink>
		<RouterLink to="/create-human">Create</RouterLink>
	</nav>
	
	<RouterView />
	
</template>

<style scoped>


</style>
