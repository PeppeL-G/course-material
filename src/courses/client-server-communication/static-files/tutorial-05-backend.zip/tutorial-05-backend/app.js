const express = require('express')
const sqlite3 = require('sqlite3')
const bodyParser = require('body-parser')
const jwt = require('jsonwebtoken')

const db = new sqlite3.Database("my-database.db")

db.run("PRAGMA foreign_keys = ON")

db.run(`
	CREATE TABLE IF NOT EXISTS tweets (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		accountId INTEGER,
		message TEXT,
		createdAt INTEGER,
		FOREIGN KEY (accountId) REFERENCES accounts(id) ON DELETE CASCADE
	)
`)

db.run(`
	CREATE TABLE IF NOT EXISTS accounts (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		username TEXT,
		password TEXT,
		CONSTRAINT unique_username UNIQUE(username)
	)
`)

const accessTokenSecret = "dfgfdgdfgdssd"

const app = express()

app.use(function(request, response, next){
	
	response.setHeader("Access-Control-Allow-Origin", "*")
	response.setHeader("Access-Control-Allow-Methods", "*")
	response.setHeader("Access-Control-Allow-Headers", "*")
	response.setHeader("Access-Control-Expose-Headers", "*")
	
	next()
	
})

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
	extended: false
}))

// GET /tweets
app.get("/tweets", function(request, response){
	
	const query = "SELECT * FROM tweets"
	
	db.all(query, function(error, tweets){
		if(error){
			response.status(500).end()
		}else{
			response.status(200).json(tweets)
		}
	})
	
})

// GET /tweets/23
app.get("/tweets/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "SELECT * FROM tweets WHERE id = ?"
	const values = [id]
	
	db.get(query, values, function(error, tweet){
		if(error){
			response.status(500).end()
		}else if(tweet){
			response.status(200).json(tweet)
		}else{
			response.status(404).end()
		}
	})
	
})

// DELETE /tweets/23
app.delete("/tweets/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "DELETE FROM tweets WHERE id = ?"
	const values = [id]
	
	db.run(query, values, function(error){
		if(error){
			response.status(500).end()
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

// POST /tweets
// Content-Type: application/json
// Authorization: Bearer THE_ACCESS_TOKEN
// Body: {"accountId": 123, "message": "Hello", "createdAt": 123123}
app.post("/tweets", function(request, response){
	
	let payload = null
	
	try{
		
		const authorizationHeader = request.get("Authorization") // "Bearer THE_ACCESS_TOKEN"
		const accessToken = authorizationHeader.substr("Bearer ".length) // "THE_ACCESS_TOKEN"
		
		payload = jwt.verify(accessToken, accessTokenSecret)
		
	}catch(e){
		// No access token provided or the access token was invalid.
	}
	
	const accountId = request.body.accountId
	const message = request.body.message
	const createdAt = request.body.createdAt
	
	// Authorization.
	if(payload == null || payload.accountId != accountId){
		response.status(401).end()
		return
	}
	
	// Validation
	const errors = []
	
	if(message.length < 3){
		errors.push("messageTooShort")
	}else if(250 < message.length){
		errors.push("messageTooLong")
	}
	
	if(0 < errors.length){
		response.status(400).json(errors)
		return
	}
	
	// Creation.
	const query = "INSERT INTO tweets (accountId, message, createdAt) VALUES (?, ?, ?)"
	const values = [accountId, message, createdAt]
	
	db.run(query, values, function(error){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: FOREIGN KEY constraint failed"){
				response.status(400).json(["accountDoesNotExist"])
			}else{
				response.status(500).end()
			}
		}else{
			
			const id = this.lastID
			
			response.setHeader("Location", "/tweets/"+id)
			response.status(201).end()
			
		}
	})
	
})

// PUT /tweets23
// Content-Type: application/json
// Body: {"id": 23, "accountId": 123, "message": "Hi", "createdAt": 321321}
app.put("/tweets/:id", function(request, response){
	
	const id = request.params.id
	const updatedAccountId = request.body.accountId
	const updatedMessage = request.body.message
	const updateCreatedAt = request.body.createdAt
	
	// TODO: Add validation the same way as in POST /tweets
	// (or whichever validation rules you want to have).
	
	// TODO: Add authorization the same way as in POST /tweets.
	
	const query = `
		UPDATE tweets SET
			accountId = ?,
			message = ?,
			createdAt = ?
		WHERE
			id = ?
	`
	const values = [updatedAccountId, updatedMessage, updateCreatedAt, id]
	
	db.run(query, values, function(error){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: FOREIGN KEY constraint failed"){
				response.status(400).json(["accountDoesNotExist"])
			}else{
				response.status(500).end()
			}
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

// POST /accounts
// Content-Type: application/json
// Body: {"username": "Alice", "password": "abc123"}
app.post("/accounts", function(request, response){
	
	const username = request.body.username
	const password = request.body.password
	
	// TODO: Validate account details.
	
	// TODO: Hash password.
	
	const query = "INSERT INTO accounts (username, password) VALUES (?, ?)"
	const values = [username, password]
	
	db.run(query, values, function(error){
		if(error){
			if(error.message == "SQLITE_CONSTRAINT: UNIQUE constraint failed: accounts.username"){
				response.status(400).json(["usernameTaken"])
			}else{
				response.status(500).end()
			}
		}else{
			
			const id = this.lastID
			
			response.setHeader("Location", "/accounts/"+id)
			response.status(201).end()
		}
	})
	
})

// Implemented per OAuth 2.0 (Resource Owner Password Credentials Grant):
// https://tools.ietf.org/html/rfc6749
// OpenID Connect also implemented (ID token).
// POST /accounts
// Content-Type: application/x-www-form-urlencoded
// Body: grant_type=password&username=Alice&password=abc123
app.post("/tokens", function(request, response){
	
	const grant_type = request.body.grant_type
	const username = request.body.username
	const password = request.body.password
	
	const query = "SELECT * FROM accounts WHERE username = ?"
	const values = [username]
	
	// TODO: Check if grant_type is valid and supported
	// (we only support grant_type=password).
	
	// TODO: Hash password.
	
	db.get(query, values, function(error, account){
		if(error){
			response.status(500).end()
		}else if(!account || account.password != password){
			response.status(400).json({error: "invalid_client"})
		}else{
			
			const accessToken = jwt.sign({
				accountId: account.id
			}, accessTokenSecret)
			
			const idToken = jwt.sign({
				sub: account.id,
				preferred_username: account.username
			}, "some secret that doesn't matter")
			
			response.status(200).json({
				access_token: accessToken,
				id_token: idToken
			})
			
		}
	})
	
})

app.listen(3000)