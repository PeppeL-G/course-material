<template>
	<div class="all-tweets">
		<h1>All Tweets</h1>
		<p>All tweets!</p>
		
		<div v-if="0 < errors.length">
			<p>Errors:</p>
			<ul>
				<li v-for="error in errors" :key="error">{{error}}</li>
			</ul>
		</div>
		
		<ul v-else>
			<li v-for="tweet in tweets" :key="tweet.id">{{tweet.message}}</li>
		</ul>
	</div>
</template>

<script>
const client = require('../client')

export default {
	data(){
		return {
			tweets: [],
			errors: []
		}
	},
	created(){
		
		client.getAllTweets((errors, tweets) => {
			if(errors.length == 0){
				this.tweets = tweets
			}else{
				this.errors = errors
			}
		})
		
	}
}
</script>