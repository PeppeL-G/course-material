<template>
	<div class="create-tweet">
		<h1>Create Tweet</h1>
		<form @submit.prevent="createTweet()">
			<div>
				Name: <input type="text" v-model="name">
			</div>
			<div>
				Message: <input type="text" v-model="message">
			</div>
			<input type="submit" value="Create">
		</form>
		<div v-if="0 < errors.length">
			<p>Errors:</p>
			<ul>
				<li v-for="error in errors" :key="error">{{error}}</li>
			</ul>
		</div>
	</div>
</template>

<script>
const client = require('../client')

export default {
	data(){
		return {
			name: "",
			message: "",
			errors: []
		}
	},
	methods: {
		createTweet(){
			
			client.createTweet(this.name, this.message, (errors, id) => {
				if(errors.length == 0){
					// Do something with the id, e.g. redirect to /tweets/id.
				}else{
					this.errors = errors
				}
			})
			
		}
	}
}
</script>