import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import CreateTweet from './views/CreateTweet.vue'
import AllTweets from './views/AllTweets.vue'

Vue.use(Router)

export default new Router({
	routes: [{
		path: '/',
		name: 'home',
		component: Home
	}, {
		path: '/all-tweets',
		name: 'all-tweets',
		component: AllTweets
	}, {
		path: '/create-tweet',
		name: 'create-tweet',
		component: CreateTweet
	}]
})
