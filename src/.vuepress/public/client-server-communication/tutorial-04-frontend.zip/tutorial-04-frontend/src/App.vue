<template>
	<div id="app">
		
		<nav>
			<router-link to="/">Home</router-link> |
			<router-link to="/all-tweets">All tweets</router-link>|
			<router-link to="/create-tweet">Create tweet</router-link>
		</nav>
		
		<router-view/>
		
	</div>
</template>