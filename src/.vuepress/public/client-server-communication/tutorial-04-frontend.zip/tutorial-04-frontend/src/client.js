exports.getAllTweets = function(callback){
	
	const request = new XMLHttpRequest()
	request.open("GET", "http://localhost:3000/tweets")
	request.send()
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 200:
				const bodyAsString = request.responseText
				const tweets = JSON.parse(bodyAsString)
				callback([], tweets)
				break
			
			case 500:
				callback(["Server error"])
				break
			
			default:
				callback(["Server error"])
				
		}
		
	})
	
}

exports.createTweet = function(name, message, callback){
	
	const tweet = {
		name,
		message,
		createdAt: Date.now()
	}
	
	const request = new XMLHttpRequest()
	request.open("POST", "http://localhost:3000/tweets")
	request.setRequestHeader("Content-Type", "application/json")
	request.send(JSON.stringify(tweet))
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 201:
				const location = request.getResponseHeader("Location")
				// TODO: Extract the id from the location header and
				// only send back the id, not the entire location.
				callback([], location)
				break
			
			case 400:
				const errors = JSON.parse(request.responseText)
				callback(errors)
				break
			
			case 500:
				callback(["Unknown server error"])
				break
			
			default:
				callback(["Unknown server error"])
			
		}
		
	})
	
}