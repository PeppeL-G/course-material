const jwtDecode = require('jwt-decode')

let accessToken = null

exports.getAllTweets = function(callback){
	
	const request = new XMLHttpRequest()
	request.open("GET", "http://localhost:3000/tweets")
	request.send()
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 200:
				const bodyAsString = request.responseText
				const tweets = JSON.parse(bodyAsString)
				callback([], tweets)
				break
			
			case 500:
				callback(["Server error"])
				break
			
			default:
				callback(["Server error"])
				
		}
		
	})
	
}

exports.createTweet = function(accountId, message, callback){
	
	const tweet = {
		accountId,
		message,
		createdAt: Date.now()
	}
	
	const request = new XMLHttpRequest()
	request.open("POST", "http://localhost:3000/tweets")
	request.setRequestHeader("Content-Type", "application/json")
	request.setRequestHeader("Authorization", "Bearer "+accessToken)
	request.send(JSON.stringify(tweet))
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 201:
				const location = request.getResponseHeader("Location")
				// TODO: Extract the id from the location header and
				// only send back the id, not the entire location.
				callback([], location)
				break
			
			case 400:
				const errors = JSON.parse(request.responseText)
				callback(errors)
				break
		
			case 401:
				callback(["unauthorired"])
				break
			
			case 500:
				callback(["Unknown server error"])
				break
			
			default:
				callback(["Unknown server error"])
			
		}
		
	})
	
}



exports.createAccount = function(username, password, callback){
	
	const account = {
		username,
		password
	}
	
	const request = new XMLHttpRequest()
	request.open("POST", "http://localhost:3000/accounts")
	request.setRequestHeader("Content-Type", "application/json")
	request.send(JSON.stringify(account))
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 201:
				const location = request.getResponseHeader("Location")
				// TODO: Extract the id from the location header and
				// only send back the id, not the entire location.
				callback([], location)
				break
			
			case 400:
				const errors = JSON.parse(request.responseText)
				callback(errors)
				break
			
			case 500:
				callback(["Unknown server error"])
				break
			
			default:
				callback(["Unknown server error"])
			
		}
		
	})
	
}





exports.login = function(username, password, callback){
	
	const request = new XMLHttpRequest()
	request.open("POST", "http://localhost:3000/tokens")
	request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
	request.send("grant_type=password&username="+encodeURIComponent(username)+"&password="+encodeURIComponent(password))
	
	request.addEventListener("load", () => {
		
		const status = request.status
		
		switch(status){
			
			case 200:
				
				var body = JSON.parse(request.responseText)
				
				const idToken = body.id_token
				accessToken = body.access_token
				
				const userInfo = jwtDecode(idToken)
				const id = userInfo.sub
				const username = userInfo.preferred_username
				
				callback([], id, username)
				break
			
			case 400:
				var body = JSON.parse(request.responseText)
				callback([body.error])
				break
			
			case 500:
				callback(["Unknown server error"])
				break
			
			default:
				callback(["Unknown server error"])
			
		}
		
	})
	
}