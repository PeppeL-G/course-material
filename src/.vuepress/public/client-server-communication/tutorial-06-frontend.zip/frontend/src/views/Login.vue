<template>
	<div class="Login">
		<h1>Login</h1>
		<form @submit.prevent="login()">
			<div>
				Username: <input type="text" v-model="username">
			</div>
			<div>
				Password: <input type="text" v-model="password">
			</div>
			<input type="submit" value="Login">
		</form>
		<div v-if="0 < errors.length">
			<p>Errors:</p>
			<ul>
				<li v-for="error in errors" :key="error">{{error}}</li>
			</ul>
		</div>
	</div>
</template>

<script>
const client = require('../client')

export default {
	data(){
		return {
			username: "",
			password: "",
			errors: []
		}
	},
	methods: {
		login(){
			
			client.login(this.username, this.password, (errors, id, username) => {
				if(errors.length == 0){
					// Do something with the id, e.g. redirect to /tweets/id.
					alert("Logged in!")
					this.$router.push("/")
				}else{
					this.errors = errors
				}
			})
			
		}
	}
}
</script>