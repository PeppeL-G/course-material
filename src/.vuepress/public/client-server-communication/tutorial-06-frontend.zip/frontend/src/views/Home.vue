<template>
	<div class="home">
		<h1>Home</h1>
		<p>This is home!</p>
	</div>
</template>