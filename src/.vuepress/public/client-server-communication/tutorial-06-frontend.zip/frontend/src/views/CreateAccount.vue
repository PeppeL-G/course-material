<template>
	<div class="create-account">
		<h1>Create Account</h1>
		<form @submit.prevent="createAccount()">
			<div>
				Username: <input type="text" v-model="username">
			</div>
			<div>
				Password: <input type="text" v-model="password">
			</div>
			<input type="submit" value="Create">
		</form>
		<div v-if="0 < errors.length">
			<p>Errors:</p>
			<ul>
				<li v-for="error in errors" :key="error">{{error}}</li>
			</ul>
		</div>
	</div>
</template>

<script>
const client = require('../client')

export default {
	data(){
		return {
			username: "",
			password: "",
			errors: []
		}
	},
	methods: {
		createAccount(){
			
			client.createAccount(this.username, this.password, (errors, id) => {
				if(errors.length == 0){
					// Do something with the id, e.g. redirect to /tweets/id.
					alert("Created!")
					this.$router.push("/")
				}else{
					this.errors = errors
				}
			})
			
		}
	}
}
</script>