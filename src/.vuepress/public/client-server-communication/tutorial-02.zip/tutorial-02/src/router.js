import Vue from 'vue'
import Router from 'vue-router'
import ListHumans from './views/ListHumans.vue'
import CreateHuman from './views/CreateHuman.vue'
import ViewHuman from './views/ViewHuman.vue'
import ViewJoke from './views/ViewJoke.vue'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'list-humans',
      component: ListHumans
    },
    {
      path: '/create-human',
      name: 'create-human',
      component: CreateHuman
    },
    {
      path: '/view-human/:id',
      name: 'view-human',
      component: ViewHuman
    },
    {
      path: '/view-joke',
      name: 'view-joke',
      component: ViewJoke
    }
  ]
})