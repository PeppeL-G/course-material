<template>
  <div>
    <h1>List Humans</h1>
    <div v-if="humans.length == 0">
      No humans exist.
    </div>
    <ul v-else>
      <li v-for="human in humans" :key="human.id">
        <router-link :to="'/view-human/'+human.id">{{human.name}}</router-link></li>
    </ul>
  </div>
</template>

<script>
import humans from '@/humans'

export default {
  data(){
    return {
      humans
    }
  }
}
</script>