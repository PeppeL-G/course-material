<template>
  <div>
    <h1>View Human</h1>
    <div v-if="human">
      <div>Id: {{human.id}}</div>
      <div>Name: {{human.name}}</div>
      <div>Age: {{human.age}}</div>
    </div>
    <p v-else>No human with that id exists.</p>
  </div>
</template>

<script>
import humans from '@/humans'

export default {
  data(){
    
    const id = this.$route.params.id
    
    const human = humans[id]
    
    return {
      human
    }
  }
}
</script>