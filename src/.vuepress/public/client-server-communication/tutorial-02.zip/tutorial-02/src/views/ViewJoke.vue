<template>
  <div>
    <h1>View Joke</h1>
    <div v-if="isError">Error...</div>
    <div v-else-if="isFetching">Loading...</div>
    <p v-else>{{joke}}</p>
  </div>
</template>

<script>
import sdk from 'chuck-norris-api'

export default {
  data(){
    return {
      isFetching: true,
      isError: false,
      joke: ""
    }
  },
  created(){
    sdk.getRandom().then((data) => {
      this.isFetching = false
      this.joke = data.value.joke
    }).catch(() => {
      this.isError = true
    })
  }
}
</script>