<template>
  <div>
    <h1>Create Human</h1>
    <form @submit.prevent="createHuman()">
      <div>
        Name: <input v-model="name">
      </div>
      <div>
        Age: <input v-model.number="age">
      </div>
      <input type="submit" value="Create">
    </form>
  </div>
</template>

<script>
import humans from '@/humans'

export default {
  data(){
    return {
      name: "",
      age: 10
    }
  },
  methods: {
    createHuman(){
      
      const human = {
        id: humans.length,
        name: this.name,
        age: this.age
      }
      
      humans.push(human)
      
      this.$router.push("/view-human/"+human.id)
      
    }
  }
}
</script>