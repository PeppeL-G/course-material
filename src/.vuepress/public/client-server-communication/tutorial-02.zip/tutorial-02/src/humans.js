export default [
	{id: 0, name: "Alice", age: 10},
	{id: 1, name: "Bob", age: 15},
	{id: 2, name: "Claire", age: 20},
]