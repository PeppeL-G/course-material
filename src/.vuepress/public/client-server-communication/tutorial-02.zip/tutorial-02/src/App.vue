<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">List Humans</router-link> |
      <router-link to="/create-human">Create Human</router-link> | 
      <router-link to="/view-joke">view Joke</router-link>
    </div>
    <hr>
    <router-view/>
  </div>
</template>