const express = require('express')
const sqlite3 = require('sqlite3')
const bodyParser = require('body-parser')

const db = new sqlite3.Database("my-database.db")

db.run(`
	CREATE TABLE IF NOT EXISTS tweets (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT,
		message TEXT,
		createdAt INTEGER
	)
`)

const app = express()

app.use(bodyParser.json())

// GET /tweets
app.get("/tweets", function(request, response){
	
	const query = "SELECT * FROM tweets"
	
	db.all(query, function(error, tweets){
		if(error){
			response.status(500).end()
		}else{
			response.status(200).json(tweets)
		}
	})
	
})

// GET /tweets/23
app.get("/tweets/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "SELECT * FROM tweets WHERE id = ?"
	const values = [id]
	
	db.get(query, values, function(error, tweet){
		if(error){
			response.status(500).end()
		}else if(tweet){
			response.status(200).json(tweet)
		}else{
			response.status(404).end()
		}
	})
	
})

// DELETE /tweets/23
app.delete("/tweets/:id", function(request, response){
	
	const id = request.params.id
	
	const query = "DELETE FROM tweets WHERE id = ?"
	const values = [id]
	
	db.run(query, values, function(error){
		if(error){
			response.status(500).end()
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

// POST /tweets
// Content-Type: application/json
// Body: {"name": "Alice", "message": "Hello", "createdAt": 123123}
app.post("/tweets", function(request, response){
	
	const name = request.body.name
	const message = request.body.message
	const createdAt = request.body.createdAt
	
	// TODO: Validate the tweet, and only create it if it passes the validation
	// (we don't want tweets with empty usernames and similar)
	
	const query = "INSERT INTO tweets (name, message, createdAt) VALUES (?, ?, ?)"
	const values = [name, message, createdAt]
	
	db.run(query, values, function(error){
		if(error){
			response.status(500).end()
		}else{
			
			const id = this.lastID
			
			response.setHeader("Location", "/tweets/"+id)
			// TODO: Maybe 201 is more suitable?
			response.status(204).end()
		}
	})
	
})

// PUT /tweets23
// Content-Type: application/json
// Body: {"id": 23, "name": "Bob", "message": "Hi", "createdAt": 321321}
app.put("/tweets/:id", function(request, response){
	
	const id = request.params.id
	const updatedName = request.body.name
	const updatedMessage = request.body.message
	const updateCreatedAt = request.body.createdAt
	
	// TODO: Validate the tweet, and only update it if it passes the validation
	// (we don't want tweets with empty usernames and similar)
	
	const query = `
		UPDATE tweets SET
			name = ?,
			message = ?,
			createdAt = ?
		WHERE
			id = ?
	`
	const values = [updatedName, updatedMessage, updateCreatedAt, id]
	
	db.run(query, values, function(error){
		if(error){
			response.status(500).end()
		}else{
			
			// TODO: Maybe 404 is more suitable if the resource didn't exist?
			// Use this.changes to find out.
			response.status(204).end()
			
		}
	})
	
})

app.listen(3000)