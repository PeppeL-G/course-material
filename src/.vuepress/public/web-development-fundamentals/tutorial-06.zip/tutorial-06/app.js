const express = require('express')
const expressHandlebars = require('express-handlebars')
const bodyParser = require('body-parser')

const app = express()

app.engine("hbs", expressHandlebars({
	defaultLayout: "main.hbs"
}))

app.use(bodyParser.urlencoded({
	extended: false
}))

app.get("/", function(request, response){
	response.render("home.hbs")
})




// Cross-Site-Scripting.
app.get("/vulnerabilities/1", function(request, response){
	
	const searchedFor = request.query.search
	
	response.send(`
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Tutorial 6 - Security</title>
		</head>
		<body>
			
			<h1>Search</h1>
			`+(
				searchedFor ?
				`<div>You searched for <b>`+searchedFor+`</b></div>` :
				""
			)+`
			<form action="" method="GET">
				Search: <input name="search">
				<input type="submit" value="Go!">
			</form>
			
		</body>
		</html>
	`)
	
})




// Cross-Site-Scripting if using {{{ }}} in Handlebars.
app.get("/vulnerabilities/2", function(request, response){
	
	const searchedFor = request.query.search
	
	const model = {
		searchedFor
	}
	
	response.render("search.hbs", model)
	
})




// Allows GET requests for any file...
const fs = require("fs")
const path = require("path")

app.use(function(request, response, next){
	
	const uri = request.url
	
	const filePath = path.join(__dirname, uri)
	
	fs.readFile(filePath, {encoding: 'utf-8'}, function(error, fileContent){
		if(error){
			next()
		}else{
			response.send(fileContent)
		}
	})
	
})




const sqlite3 = require('sqlite3')

const db = new sqlite3.Database("my-database.db")

db.serialize(function(){
	
	db.run(`
		CREATE TABLE IF NOT EXISTS accounts (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			username TEXT,
			password TEXT
		)
	`)
	
	db.run(`
		INSERT INTO accounts (username, password)
		VALUES ('Alice', 'abc123')`
	)
	
	db.run(`
		INSERT INTO accounts (username, password)
		VALUES ('Bob', 'bob123')`
	)
	
})

app.get("/vulnerabilities/3", function(request, response){
	
	const model = {
		isLoggedIn: false
	}
	
	response.render("login.hbs", model)
	
})

// SQL injection.
app.post("/vulnerabilities/3", function(request, response){
	
	const username = request.body.username
	const password = request.body.password
	
	const query = `
		SELECT * FROM accounts WHERE
		username = `+username+` AND
		password = `+password+`
	`
	
	const values = [username, password]
	
	console.log(query)
	
	db.get(query, values, function(error, account){
	
		const model = {
			isLoggedIn: (!error && account)
		}
		
		response.render("login.hbs", model)
		
	})
	
})




// Possible to figure out account passwords.
app.get("/vulnerabilities/4", function(request, response){
	
	const whereField = request.query.whereField
	const whereValue = request.query.whereValue
	
	if(whereField){
		
		const query = `
			SELECT * FROM accounts WHERE `+whereField+` LIKE ?
		`
		const values = [whereValue]
		
		db.all(query, values, function(error, accounts){
			
			const model = {
				accounts
			}
			
			response.render("search-accounts.hbs", model)
			
		})
		
	}else{
		
		const model = {
			accounts: []
		}
		
		response.render("search-accounts.hbs", model)
		
	}
	
})




app.listen(8080)