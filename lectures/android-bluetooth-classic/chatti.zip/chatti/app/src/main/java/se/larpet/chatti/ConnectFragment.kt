package se.larpet.chatti


import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ConnectFragment : Fragment() {

    companion object {

        fun newInstance() =
            ConnectFragment().apply {
                arguments = Bundle().apply {
                }
            }

        const val REQUEST_CODE_MAKE_DISCOVERABLE = 1111

    }

    lateinit var recyclerView: RecyclerView

    // TODO: Handle runtime configuration changes...
    val foundDevices = mutableListOf<BluetoothDevice>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(
        R.layout.fragment_connect,
        container,
        false
    )!!

    private val deviceFoundReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {

            val foundDevice = intent!!.getParcelableExtra<BluetoothDevice>(
                BluetoothDevice.EXTRA_DEVICE
            )!!

            foundDevices.add(foundDevice)
            recyclerView.adapter!!.notifyItemInserted(foundDevices.size - 1)

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.client_button).setOnClickListener {

            // TODO: No need to start discovery if it's already running.
            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
            bluetoothAdapter.startDiscovery()

            // TODO: Should probably disable button so user can't click on it again.
            // TODO: Listen for when discovery ends and enable the button.

        }

        view.findViewById<Button>(R.id.server_button).setOnClickListener {

            startActivityForResult(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE),
                REQUEST_CODE_MAKE_DISCOVERABLE
            )

        }

        recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = DeviceAdapter(foundDevices, this, context!!)
        }

    }

    override fun onStart() {
        super.onStart()
        context!!.registerReceiver(
            deviceFoundReceiver,
            IntentFilter(BluetoothDevice.ACTION_FOUND)
        )
    }

    override fun onStop() {
        super.onStop()
        context!!.unregisterReceiver(deviceFoundReceiver)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == REQUEST_CODE_MAKE_DISCOVERABLE){
            if(resultCode != Activity.RESULT_CANCELED){
                context!!.startService(Intent(context, ChatService::class.java).apply{
                    action = ChatService.ACTION_START_SERVER
                })
            }
        }

    }

}

class DeviceViewHolder(
    rootView: View,
    recyclerView: RecyclerView,
    foundDevices: MutableList<BluetoothDevice>
) : RecyclerView.ViewHolder(rootView){

    val textView = rootView.findViewById<TextView>(R.id.text_view)!!.apply {
        setOnClickListener {

            BluetoothAdapter.getDefaultAdapter().cancelDiscovery()

            val position = recyclerView.getChildLayoutPosition(rootView)
            val device = foundDevices[position]

            context.startService(
                Intent(context, ChatService::class.java).apply {
                    action = ChatService.ACTION_START_CLIENT
                    putExtra(ChatService.EXTRA_SERVER, device)
                }
            )
        }
    }

}

class DeviceAdapter(
    private val foundDevices: MutableList<BluetoothDevice>,
    private val recyclerView: RecyclerView,
    private val context: Context
) : RecyclerView.Adapter<DeviceViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        return DeviceViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.recycler_view_device,
                parent,
                false
            ),
            recyclerView,
            foundDevices
        )
    }

    override fun getItemCount() = foundDevices.size

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {

        val device = foundDevices[position]

        // Warning is OK, we can't translate this.
        holder.textView.text = "${device.name} ${device.address}"

    }

}