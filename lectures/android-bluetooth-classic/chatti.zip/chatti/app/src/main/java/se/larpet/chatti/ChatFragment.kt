package se.larpet.chatti


import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatFragment : Fragment() {

    companion object {

        fun newInstance() =
            ChatFragment().apply {
                arguments = Bundle().apply {
                }
            }

    }

    val messages = mutableListOf<Message>()
    lateinit var recyclerView: RecyclerView

    private val messageReceivedReceiver = object: BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {

            val messageText = intent!!.getStringExtra(ChatService.EXTRA_MESSAGE)!!

            // TODO: Don't hardcode English.
            messages.add(Message(
                "Remote", // TODO: Don't hardcode English.
                messageText
            ))

            recyclerView.adapter!!.notifyItemInserted(messages.size-1)

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = inflater.inflate(
        R.layout.fragment_chat,
        container,
        false
    )!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = MessageAdapter(messages, context)
        }

        view.findViewById<Button>(R.id.send_button).setOnClickListener {

            val editText = view.findViewById<EditText>(R.id.edit_text)
            val message = editText.text.toString()

            context!!.startService(
                Intent(context, ChatService::class.java).apply {
                    action = ChatService.ACTION_SEND_MESSAGE
                    putExtra(ChatService.EXTRA_MESSAGE, message)
                }
            )

            messages.add(
                Message(
                    "Local", // TODO: Don't hardcode English.
                    message
                )
            )
            recyclerView.adapter!!.notifyItemInserted(messages.size - 1)

            editText.text.clear()

        }

    }

    override fun onStart() {
        super.onStart()

        LocalBroadcastManager.getInstance(context!!).registerReceiver(
            messageReceivedReceiver,
            IntentFilter(ChatService.ACTION_MESSAGE_RECEIVED)
        )

    }

    override fun onStop() {
        super.onStop()

        LocalBroadcastManager.getInstance(context!!).unregisterReceiver(
            messageReceivedReceiver
        )

    }

}

data class Message(
    val authorName: String,
    val text: String
)

class MessageViewHolder(
    rootView: View
) : RecyclerView.ViewHolder(rootView){

    val textView = rootView.findViewById<TextView>(R.id.text_view)!!

}

class MessageAdapter(
    private val messages: MutableList<Message>,
    private val context: Context
) : RecyclerView.Adapter<MessageViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return MessageViewHolder(
            LayoutInflater.from(context).inflate(
                R.layout.recycler_view_message,
                parent,
                false
            )
        )
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {

        val message = messages[position]

        // Warning is OK, we can't translate this.
        holder.textView.text = "${message.authorName}: ${message.text}"

    }

}