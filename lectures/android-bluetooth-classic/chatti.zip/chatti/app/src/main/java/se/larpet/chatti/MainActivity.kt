package se.larpet.chatti

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class MainActivity : AppCompatActivity() {

    // TODO: Handle runtime configuration changes.
    var isConnected = false

    private val bluetoothStateChangeReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            changeFragment()
        }
    }

    private val connectedReceiver = object: BroadcastReceiver(){
        override fun onReceive(context: Context?, intent: Intent?) {
            isConnected = true
            changeFragment()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()

        // TODO: Should not change fragment if we don't need to
        // (we'll lose the state of the fragment).
        changeFragment()

        registerReceiver(
            bluetoothStateChangeReceiver,
            IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
        )

        LocalBroadcastManager.getInstance(this).registerReceiver(
            connectedReceiver,
            IntentFilter(ChatService.ACTION_CONNECTION_ESTABLISHED)
        )

    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(bluetoothStateChangeReceiver)
    }

    // TODO: What if bluetooth is not supported?
    private fun isBluetoothEnabled() = BluetoothAdapter.getDefaultAdapter().run {
        this != null && isEnabled
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(requestCode == GrantPermissionFragment.REQUEST_CODE_LOCATION_PERMISSION){
            changeFragment()
        }

    }

    private fun haveAllPermissions() = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED

    fun changeFragment(){

        val fragment = when{
            !isBluetoothEnabled() -> EnableBluetoothFragment.newInstance()
            !haveAllPermissions() -> GrantPermissionFragment.newInstance()
            !isConnected -> ConnectFragment.newInstance()
            else -> ChatFragment.newInstance()
        }

        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frame_layout, fragment)
            .commit()

    }

}
