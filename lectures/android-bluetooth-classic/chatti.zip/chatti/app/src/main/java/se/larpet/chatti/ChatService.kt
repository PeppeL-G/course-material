package se.larpet.chatti

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.os.IBinder
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.nio.charset.StandardCharsets
import java.util.*
import kotlin.concurrent.thread

// TODO: Handle errors!
class ChatService : Service() {

    companion object {

        // The UUID for the chat service.
        val chatServiceUuid = UUID.fromString("35778cb0-6fe6-4cc8-860f-02bd43b923ae")

        // Action for start listening for incoming Bluetooth connection requests.
        const val ACTION_START_SERVER = "ACTION_START_SERVER"

        // Action for connecting to a remote Bluetooth device.
        // EXTRA_SERVER should be the BluetoothDevice to connect to.
        const val ACTION_START_CLIENT = "ACTION_START_CLIENT"
        const val EXTRA_SERVER = "EXTRA_SERVER"

        // Action for sending a message to the remote Bluetooth device.
        // EXTRA_MESSAGE should be the string to send.
        const val ACTION_SEND_MESSAGE = "AVTION_SEND_MESSAGE"
        const val EXTRA_MESSAGE = "EXTRA_MESSAGE"

        // Action broadcasted (locally) when a connection is established.
        const val ACTION_CONNECTION_ESTABLISHED = "ACTION_CONNECTION_ESTABLISHED"

        // Action broadcasted (locally) when a message is received form the other device.
        // EXTRA_MESSAGE is the string received.
        const val ACTION_MESSAGE_RECEIVED = "ACTION_MESSAGE_RECEIVED"

    }

    // BluetoothSocket to the connected bluetooth device.
    private lateinit var remoteSocket: BluetoothSocket

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        when(intent!!.action){
            ACTION_START_SERVER -> startServer()
            ACTION_START_CLIENT -> {
                val server = intent.getParcelableExtra<BluetoothDevice>(EXTRA_SERVER)!!
                startClient(server)
            }
            ACTION_SEND_MESSAGE -> {
                val message = intent.getStringExtra(EXTRA_MESSAGE)!!
                sendMessage(message)
            }
        }

        return START_REDELIVER_INTENT

    }

    private fun sendMessage(message: String) {

        thread {

            remoteSocket.outputStream.write(
                message.toByteArray()
            )

        }

    }

    private fun setRemote(remoteSocket: BluetoothSocket){

        this.remoteSocket = remoteSocket

        val localBroadcastManager = LocalBroadcastManager.getInstance(baseContext)

        localBroadcastManager.sendBroadcast(
            Intent(ACTION_CONNECTION_ESTABLISHED)
        )

        // TODO: Start running the service in foreground might be good?

        thread {

            // TODO: We don't want to listen forever...
            while(true){

                val bytes = ByteArray(512)
                val numberOfBytesRead = remoteSocket.inputStream.read(bytes)
                val message = String(bytes, 0, numberOfBytesRead)

                // TODO: If no one listens for the broadcast,
                // maybe displaying a notification makes sense?
                localBroadcastManager.sendBroadcast(
                    Intent(ACTION_MESSAGE_RECEIVED).apply {
                        putExtra(EXTRA_MESSAGE, message)
                    }
                )

                // TODO: Maybe storing the messages in a database makes sense?

            }

        }

    }

    private fun startServer(){

        thread {

            val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

            val server = bluetoothAdapter.listenUsingRfcommWithServiceRecord(
                "My service",
                chatServiceUuid
            )

            // TODO: We don't want to wait forever, do we?
            val client = server.accept()

            server.close()

            setRemote(client)

        }

    }

    private fun startClient(serverDevice: BluetoothDevice){

        thread {

            val serverSocket = serverDevice.createRfcommSocketToServiceRecord(chatServiceUuid)

            // TODO: What if we can't connect to the other device? Handle it!
            serverSocket.connect()

            setRemote(serverSocket)

        }

    }

    override fun onBind(intent: Intent): IBinder {
        TODO("Not used.")
    }

}
